export interface Comment {
  id: string
  username: string
  text: string
  timestamp: string
}
