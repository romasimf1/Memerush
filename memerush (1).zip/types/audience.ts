export interface AudienceData {
  totalFollowers: number
  followerGrowth: number
  avgEngagement: number
  engagementChange: number
  activeFollowers: number
  reach: number
  demographics: {
    ageData: any
    genderData: any
  }
  interests: any
  activityPatterns: any
  locations: any
}

export interface Follower {
  id: string
  username: string
  displayName: string
  avatar: string
  followerCount: number
  engagementRate: number
  isInfluencer: boolean
  youFollow: boolean
  lastActive: string
}

export interface AudienceSegment {
  id: string
  name: string
  audienceSize: number
  createdAt: string
  updatedAt: string
  criteria: string[]
}
