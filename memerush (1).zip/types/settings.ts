export interface UserSettings {
  username: string
  displayName: string
  email: string
  bio?: string
  avatar?: string
  website?: string
  location?: string
  theme: "light" | "dark" | "system"
  accentColor?: string
  language?: string
  notifications?: {
    newFollowers: boolean
    likes: boolean
    comments: boolean
    mentions: boolean
    directMessages: boolean
    newContent: boolean
    emailNotifications: boolean
    pushNotifications: boolean
  }
  privacy?: {
    privateAccount: boolean
    showActivity: boolean
    allowTagging: string
    allowComments: string
    allowDirectMessages: string
    dataPersonalization: boolean
  }
}
