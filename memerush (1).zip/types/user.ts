export interface User {
  username: string
  displayName: string
  avatar?: string
  bio?: string
  followers: number
  following: number
  isCurrentUser: boolean
  isFollowing?: boolean
  notificationsEnabled?: boolean
}

export interface FollowerUser {
  username: string
  displayName: string
  avatar?: string
  isFollowing: boolean
  isCurrentUser: boolean
}
