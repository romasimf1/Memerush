export interface Campaign {
  id: string
  name: string
  status: "active" | "scheduled" | "completed" | "paused"
  goal: string
  startDate: string
  endDate: string
  budget: number
  reach: number
  engagementRate: number
  conversionRate: number
  performance: string
  progress: number
}
