import type { Comment } from "./comment"

export interface Meme {
  id: string
  type: "image" | "video"
  src: string
  username: string
  likes: number
  liked: boolean
  comments?: Comment[]
  description?: string
}
