export interface ScheduledPost {
  id: string
  mediaType: "image" | "video"
  mediaSrc: string
  description: string
  scheduledFor: string
  platforms: string[]
  tags: string[]
  status: "scheduled" | "paused" | "published" | "failed"
  createdAt: string
}

export interface Draft {
  id: string
  mediaType: "image" | "video"
  mediaSrc: string
  description: string
  platforms: string[]
  tags: string[]
  createdAt: string
  updatedAt: string
}
