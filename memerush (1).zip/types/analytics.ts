export interface AnalyticsData {
  totalViews: number
  viewsChange: number
  engagementRate: number
  engagementChange: number
  newFollowers: number
  followersChange: number
  conversionRate: number
  conversionChange: number
  performanceData: any
  demographicsData: any
  audienceData: any
  topContent: TopContent[]
  recentActivities: Activity[]
  scheduledPosts: any[]
}

export interface TopContent {
  id: string
  title: string
  thumbnail: string
  performance: string
  likes: number
  comments: number
  shares: number
}

export interface Activity {
  id: string
  type: "like" | "comment" | "follow" | "share"
  username: string
  timestamp: string
  content: string
}

export interface AudienceData {
  labels: string[]
  datasets: {
    label: string
    data: number[]
    backgroundColor: string | string[]
  }[]
}
