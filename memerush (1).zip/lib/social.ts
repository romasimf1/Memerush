import type { FollowerUser } from "@/types/user"
import { getCurrentUser } from "./auth"

// Mock followers data
const mockFollowers: Record<string, FollowerUser[]> = {
  demouser: [
    {
      username: "memequeen",
      displayName: "Meme Queen",
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: true,
      isCurrentUser: false,
    },
    {
      username: "memer42",
      displayName: "Meme Master",
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: false,
      isCurrentUser: false,
    },
    {
      username: "laughalot",
      displayName: "Laugh A Lot",
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: true,
      isCurrentUser: false,
    },
    {
      username: "viralking",
      displayName: "Viral King",
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: false,
      isCurrentUser: false,
    },
  ],
  memequeen: [
    {
      username: "demouser",
      displayName: "Demo User",
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: true,
      isCurrentUser: false,
    },
    {
      username: "viralking",
      displayName: "Viral King",
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: true,
      isCurrentUser: false,
    },
  ],
}

// Mock following data
const mockFollowing: Record<string, FollowerUser[]> = {
  demouser: [
    {
      username: "memequeen",
      displayName: "Meme Queen",
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: true,
      isCurrentUser: false,
    },
    {
      username: "laughalot",
      displayName: "Laugh A Lot",
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: true,
      isCurrentUser: false,
    },
  ],
  memequeen: [
    {
      username: "demouser",
      displayName: "Demo User",
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: true,
      isCurrentUser: false,
    },
  ],
}

// Mock notifications settings
const mockNotifications: Record<string, string[]> = {
  demouser: ["memequeen", "laughalot"],
  memequeen: ["demouser"],
}

// Get user followers
export const getUserFollowers = async (username: string): Promise<FollowerUser[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // Get followers for the requested user
  const followers = mockFollowers[username] || []

  // Mark if each follower is the current user
  return followers.map((follower) => ({
    ...follower,
    isCurrentUser: follower.username === currentUser.username,
    // Update isFollowing based on current user's following list
    isFollowing: mockFollowing[currentUser.username]?.some((f) => f.username === follower.username) || false,
  }))
}

// Get user following
export const getUserFollowing = async (username: string): Promise<FollowerUser[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // Get following for the requested user
  const following = mockFollowing[username] || []

  // Mark if each following is the current user
  return following.map((user) => ({
    ...user,
    isCurrentUser: user.username === currentUser.username,
    // Update isFollowing based on current user's following list
    isFollowing: mockFollowing[currentUser.username]?.some((f) => f.username === user.username) || false,
  }))
}

// Follow a user
export const followUser = async (username: string): Promise<void> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // Add to current user's following list if not already following
  if (!mockFollowing[currentUser.username]) {
    mockFollowing[currentUser.username] = []
  }

  if (!mockFollowing[currentUser.username].some((f) => f.username === username)) {
    // Get user details to add to following
    const userToFollow = Object.values(mockFollowers)
      .flat()
      .find((u) => u.username === username) || {
      username,
      displayName: username,
      avatar: "/placeholder.svg?height=48&width=48",
      isFollowing: true,
      isCurrentUser: false,
    }

    mockFollowing[currentUser.username].push({
      ...userToFollow,
      isFollowing: true,
      isCurrentUser: false,
    })
  }

  // Add current user to the followed user's followers list
  if (!mockFollowers[username]) {
    mockFollowers[username] = []
  }

  if (!mockFollowers[username].some((f) => f.username === currentUser.username)) {
    mockFollowers[username].push({
      username: currentUser.username,
      displayName: currentUser.displayName,
      avatar: currentUser.avatar || "/placeholder.svg?height=48&width=48",
      isFollowing: false, // The followed user is not following the current user by default
      isCurrentUser: false,
    })
  }

  // Enable notifications by default
  if (!mockNotifications[currentUser.username]) {
    mockNotifications[currentUser.username] = []
  }

  if (!mockNotifications[currentUser.username].includes(username)) {
    mockNotifications[currentUser.username].push(username)
  }
}

// Unfollow a user
export const unfollowUser = async (username: string): Promise<void> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // Remove from current user's following list
  if (mockFollowing[currentUser.username]) {
    mockFollowing[currentUser.username] = mockFollowing[currentUser.username].filter((f) => f.username !== username)
  }

  // Remove current user from the unfollowed user's followers list
  if (mockFollowers[username]) {
    mockFollowers[username] = mockFollowers[username].filter((f) => f.username !== currentUser.username)
  }

  // Remove notifications
  if (mockNotifications[currentUser.username]) {
    mockNotifications[currentUser.username] = mockNotifications[currentUser.username].filter((u) => u !== username)
  }
}

// Toggle notifications for a user
export const toggleNotifications = async (username: string, enabled: boolean): Promise<void> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 300))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  if (!mockNotifications[currentUser.username]) {
    mockNotifications[currentUser.username] = []
  }

  if (enabled) {
    // Enable notifications if not already enabled
    if (!mockNotifications[currentUser.username].includes(username)) {
      mockNotifications[currentUser.username].push(username)
    }
  } else {
    // Disable notifications
    mockNotifications[currentUser.username] = mockNotifications[currentUser.username].filter((u) => u !== username)
  }
}

// Check if notifications are enabled for a user
export const checkNotificationsEnabled = async (username: string): Promise<boolean> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 200))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    return false
  }

  return mockNotifications[currentUser.username]?.includes(username) || false
}
