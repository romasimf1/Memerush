import type { Meme } from "@/types/meme"
import type { User } from "@/types/user"
import type { Comment } from "@/types/comment"
import { getCurrentUser } from "./auth"
import { checkNotificationsEnabled } from "./social"

// Mock data for MVP
const mockMemes: Meme[] = [
  {
    id: "meme1",
    type: "image",
    src: "/placeholder.svg?height=800&width=600&text=Funny+Meme+1",
    username: "demouser",
    likes: 42,
    liked: false,
    comments: [
      {
        id: "comment1",
        username: "user123",
        text: "This is hilarious! 😂",
        timestamp: "2023-05-15T10:30:00Z",
      },
      {
        id: "comment2",
        username: "memer42",
        text: "I can't stop laughing!",
        timestamp: "2023-05-15T11:15:00Z",
      },
    ],
    description: "When you finally fix that bug after 5 hours",
  },
  {
    id: "meme2",
    type: "image",
    src: "/placeholder.svg?height=800&width=600&text=Funny+Meme+2",
    username: "memequeen",
    likes: 128,
    liked: true,
    comments: [],
    description: "Monday morning vibes",
  },
  {
    id: "meme3",
    type: "image",
    src: "/placeholder.svg?height=800&width=600&text=Funny+Meme+3",
    username: "demouser",
    likes: 76,
    liked: false,
    comments: [
      {
        id: "comment3",
        username: "laughalot",
        text: "This is so relatable!",
        timestamp: "2023-05-16T09:45:00Z",
      },
    ],
    description: "When someone asks if I'm productive working from home",
  },
  {
    id: "meme4",
    type: "image",
    src: "/placeholder.svg?height=800&width=600&text=Funny+Meme+4",
    username: "laughalot",
    likes: 95,
    liked: false,
    comments: [],
    description: "Weekend plans be like",
  },
  {
    id: "meme5",
    type: "image",
    src: "/placeholder.svg?height=800&width=600&text=Funny+Meme+5",
    username: "memequeen",
    likes: 210,
    liked: false,
    comments: [],
    description: "That feeling when the code works on the first try",
  },
]

// Get all memes for the feed
export const getMemes = async (): Promise<Meme[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return [...mockMemes]
}

// Get following feed (memes from users the current user follows)
export const getFollowingFeed = async (): Promise<Meme[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would filter memes based on the users the current user follows
  // For demo purposes, we'll return a subset of memes
  return mockMemes.filter((meme) => meme.username === "memequeen" || meme.username === "laughalot")
}

// Get memes by username
export const getUserMemes = async (username: string): Promise<Meme[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  return mockMemes.filter((meme) => meme.username === username)
}

// Get user profile
export const getUserProfile = async (username: string): Promise<User> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  // Check if this is the current user
  const currentUser = getCurrentUser()
  const isCurrentUser = currentUser?.username === username

  // Check if the current user is following this user
  let isFollowing = false
  let notificationsEnabled = false

  if (currentUser && !isCurrentUser) {
    // In a real app, this would check the database
    // For demo, we'll use hardcoded values
    isFollowing = username === "memequeen" || username === "laughalot"
    notificationsEnabled = await checkNotificationsEnabled(username)
  }

  if (username === "demouser" || (isCurrentUser && currentUser?.username === "demouser")) {
    return {
      username: "demouser",
      displayName: "Demo User",
      avatar: "/placeholder.svg?height=200&width=200",
      bio: "Just here for the memes!",
      followers: 42,
      following: 17,
      isCurrentUser,
      isFollowing,
      notificationsEnabled,
    }
  }

  if (username === "memequeen") {
    return {
      username: "memequeen",
      displayName: "Meme Queen",
      avatar: "/placeholder.svg?height=200&width=200",
      bio: "Professional meme curator",
      followers: 1024,
      following: 256,
      isCurrentUser: false,
      isFollowing,
      notificationsEnabled,
    }
  }

  if (username === "laughalot") {
    return {
      username: "laughalot",
      displayName: "Laugh A Lot",
      avatar: "/placeholder.svg?height=200&width=200",
      bio: "Here for the laughs 😂",
      followers: 512,
      following: 128,
      isCurrentUser: false,
      isFollowing,
      notificationsEnabled,
    }
  }

  // If we're here, it's the current user but not one of our mock users
  if (isCurrentUser && currentUser) {
    return {
      username: currentUser.username,
      displayName: currentUser.displayName,
      avatar: currentUser.avatar,
      bio: "New to Memerush!",
      followers: 0,
      following: 0,
      isCurrentUser: true,
      isFollowing: false,
      notificationsEnabled: false,
    }
  }

  throw new Error("User not found")
}

// Upload a meme
export const uploadMeme = async (file: File, description: string): Promise<Meme> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 2000))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would upload to Cloudinary or similar
  // For MVP, we'll just create a mock meme
  const newMeme: Meme = {
    id: `meme-${Date.now()}`,
    type: file.type.startsWith("video/") ? "video" : "image",
    // In a real app, this would be the URL from Cloudinary
    src: URL.createObjectURL(file),
    username: currentUser.username,
    likes: 0,
    liked: false,
    comments: [],
    description,
  }

  // In a real app, this would be saved to a database
  mockMemes.unshift(newMeme)

  return newMeme
}

// Add a comment to a meme
export const addComment = async (memeId: string, text: string): Promise<Comment> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  const meme = mockMemes.find((m) => m.id === memeId)
  if (!meme) {
    throw new Error("Meme not found")
  }

  const newComment: Comment = {
    id: `comment-${Date.now()}`,
    username: currentUser.username,
    text,
    timestamp: new Date().toISOString(),
  }

  if (!meme.comments) {
    meme.comments = []
  }

  meme.comments.unshift(newComment)

  return newComment
}

// Like or unlike a meme
export const toggleLike = async (memeId: string): Promise<{ liked: boolean; likes: number }> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 300))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  const meme = mockMemes.find((m) => m.id === memeId)
  if (!meme) {
    throw new Error("Meme not found")
  }

  meme.liked = !meme.liked
  meme.likes = meme.liked ? meme.likes + 1 : meme.likes - 1

  return { liked: meme.liked, likes: meme.likes }
}
