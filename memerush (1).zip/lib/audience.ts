import type { AudienceData, Follower, AudienceSegment } from "@/types/audience"

// Mock audience data for MVP
export const getAudienceData = async (): Promise<AudienceData> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  // Mock demographics data
  const ageData = {
    labels: ["18-24", "25-34", "35-44", "45-54", "55+"],
    datasets: [
      {
        label: "Age Distribution",
        data: [35, 40, 15, 7, 3],
        backgroundColor: "rgba(99, 102, 241, 0.7)",
      },
    ],
  }

  const genderData = {
    labels: ["Male", "Female", "Non-binary", "Other"],
    datasets: [
      {
        label: "Gender Distribution",
        data: [55, 40, 3, 2],
        backgroundColor: [
          "rgba(99, 102, 241, 0.7)",
          "rgba(236, 72, 153, 0.7)",
          "rgba(16, 185, 129, 0.7)",
          "rgba(107, 114, 128, 0.7)",
        ],
      },
    ],
  }

  // Mock interests data
  const interests = {
    labels: ["Humor", "Technology", "Gaming", "Movies", "Music", "Sports", "Food", "Travel"],
    datasets: [
      {
        label: "Interests",
        data: [85, 65, 60, 55, 50, 45, 40, 35],
        backgroundColor: "rgba(99, 102, 241, 0.7)",
      },
    ],
  }

  // Mock activity patterns data
  const activityPatterns = {
    labels: ["12am", "3am", "6am", "9am", "12pm", "3pm", "6pm", "9pm"],
    datasets: [
      {
        label: "Activity",
        data: [10, 5, 8, 30, 45, 60, 75, 55],
        backgroundColor: "rgba(99, 102, 241, 0.7)",
      },
    ],
  }

  // Mock locations data
  const locations = {
    labels: ["United States", "United Kingdom", "Canada", "Australia", "Germany", "France", "Other"],
    datasets: [
      {
        label: "Locations",
        data: [45, 15, 10, 8, 7, 5, 10],
        backgroundColor: "rgba(99, 102, 241, 0.7)",
      },
    ],
  }

  return {
    totalFollowers: 12500,
    followerGrowth: 15,
    avgEngagement: 4.8,
    engagementChange: 0.5,
    activeFollowers: 68,
    reach: 35000,
    demographics: {
      ageData,
      genderData,
    },
    interests,
    activityPatterns,
    locations,
  }
}

// Mock followers for MVP
const mockFollowers: Follower[] = [
  {
    id: "follower1",
    username: "memer42",
    displayName: "Meme Master",
    avatar: "/placeholder.svg?height=48&width=48",
    followerCount: 1250,
    engagementRate: 5.2,
    isInfluencer: true,
    youFollow: true,
    lastActive: "Today",
  },
  {
    id: "follower2",
    username: "laughalot",
    displayName: "Laugh A Lot",
    avatar: "/placeholder.svg?height=48&width=48",
    followerCount: 850,
    engagementRate: 4.8,
    isInfluencer: false,
    youFollow: false,
    lastActive: "Yesterday",
  },
  {
    id: "follower3",
    username: "memequeen",
    displayName: "Meme Queen",
    avatar: "/placeholder.svg?height=48&width=48",
    followerCount: 3200,
    engagementRate: 6.5,
    isInfluencer: true,
    youFollow: true,
    lastActive: "2 days ago",
  },
  {
    id: "follower4",
    username: "viralking",
    displayName: "Viral King",
    avatar: "/placeholder.svg?height=48&width=48",
    followerCount: 5600,
    engagementRate: 7.2,
    isInfluencer: true,
    youFollow: false,
    lastActive: "Today",
  },
  {
    id: "follower5",
    username: "user123",
    displayName: "Regular User",
    avatar: "/placeholder.svg?height=48&width=48",
    followerCount: 320,
    engagementRate: 3.5,
    isInfluencer: false,
    youFollow: true,
    lastActive: "1 week ago",
  },
]

// Get followers
export const getFollowers = async (): Promise<Follower[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  return [...mockFollowers]
}

// Mock audience segments for MVP
const mockSegments: AudienceSegment[] = [
  {
    id: "segment1",
    name: "Highly Engaged",
    audienceSize: 2500,
    createdAt: "2 weeks ago",
    updatedAt: "Yesterday",
    criteria: ["Engagement rate > 5%", "Active in last 7 days", "Commented on posts"],
  },
  {
    id: "segment2",
    name: "Influencers",
    audienceSize: 850,
    createdAt: "1 month ago",
    updatedAt: "3 days ago",
    criteria: ["Follower count > 1000", "Verified accounts", "High reach"],
  },
  {
    id: "segment3",
    name: "New Followers",
    audienceSize: 1200,
    createdAt: "1 week ago",
    updatedAt: "Today",
    criteria: ["Followed in last 30 days", "Viewed stories", "Under 25 years old"],
  },
]

// Get audience segments
export const getAudienceSegments = async (): Promise<AudienceSegment[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  return [...mockSegments]
}
