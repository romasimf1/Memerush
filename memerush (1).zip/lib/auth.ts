// Mock authentication for MVP
// In a real app, this would be replaced with NextAuth, Clerk, or a custom auth solution

// Store user data in localStorage
const USER_KEY = "memerush_user"
const TOKEN_KEY = "memerush_token"

// Mock user data
const mockUsers = [
  {
    id: "1",
    email: "user@example.com",
    username: "demouser",
    password: "password123",
    displayName: "Demo User",
    avatar: "/placeholder.svg?height=200&width=200",
    bio: "Just here for the memes!",
    followers: 42,
    following: 17,
  },
]

export interface AuthUser {
  id: string
  email: string
  username: string
  displayName: string
  avatar?: string
}

// Check if user is authenticated
export const checkAuth = async (): Promise<boolean> => {
  // For demo purposes, we'll just check if there's a token in localStorage
  if (typeof window === "undefined") return false

  const token = localStorage.getItem(TOKEN_KEY)
  return !!token
}

// Login user
export const loginUser = async (email: string, password: string): Promise<AuthUser> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Find user
  const user = mockUsers.find((u) => u.email === email && u.password === password)

  if (!user) {
    throw new Error("Invalid credentials")
  }

  // Create a token (in a real app, this would be a JWT)
  const token = `mock-token-${Date.now()}`

  // Store user data and token
  const authUser: AuthUser = {
    id: user.id,
    email: user.email,
    username: user.username,
    displayName: user.displayName,
    avatar: user.avatar,
  }

  localStorage.setItem(USER_KEY, JSON.stringify(authUser))
  localStorage.setItem(TOKEN_KEY, token)

  return authUser
}

// Register user
export const registerUser = async (email: string, username: string, password: string): Promise<AuthUser> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Check if user already exists
  if (mockUsers.some((u) => u.email === email || u.username === username)) {
    throw new Error("User already exists")
  }

  // Create new user
  const newUser = {
    id: `user-${Date.now()}`,
    email,
    username,
    password,
    displayName: username,
    avatar: "/placeholder.svg?height=200&width=200",
    bio: "",
    followers: 0,
    following: 0,
  }

  // In a real app, this would be saved to a database
  mockUsers.push(newUser)

  // Create a token (in a real app, this would be a JWT)
  const token = `mock-token-${Date.now()}`

  // Store user data and token
  const authUser: AuthUser = {
    id: newUser.id,
    email: newUser.email,
    username: newUser.username,
    displayName: newUser.displayName,
    avatar: newUser.avatar,
  }

  localStorage.setItem(USER_KEY, JSON.stringify(authUser))
  localStorage.setItem(TOKEN_KEY, token)

  return authUser
}

// Logout user
export const logoutUser = async (): Promise<void> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Clear user data and token
  localStorage.removeItem(USER_KEY)
  localStorage.removeItem(TOKEN_KEY)
}

// Get current user
export const getCurrentUser = (): AuthUser | null => {
  if (typeof window === "undefined") return null

  const userJson = localStorage.getItem(USER_KEY)
  if (!userJson) return null

  return JSON.parse(userJson) as AuthUser
}
