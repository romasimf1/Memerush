"use client"

import type React from "react"

import { useState, useEffect, createContext, useContext } from "react"

// Define available languages
export type Language = "en" | "ru" | "es"

// Define translation context
interface TranslationContextType {
  t: (key: string, params?: Record<string, string>) => string
  language: Language
  changeLanguage: (lang: string) => void
}

const TranslationContext = createContext<TranslationContextType>({
  t: (key) => key,
  language: "en",
  changeLanguage: () => {},
})

// Translation provider component
export function TranslationProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")
  const [translations, setTranslations] = useState<Record<string, string>>({})

  useEffect(() => {
    // Load translations based on user settings or browser language
    const userLanguage = (localStorage.getItem("language") as Language) || "en"
    setLanguage(userLanguage)
    loadTranslations(userLanguage)
  }, [])

  const loadTranslations = async (lang: string) => {
    // In a real app, this would load translations from a file or API
    // For demo purposes, we'll use hardcoded translations
    setTranslations(getTranslations(lang as Language))
  }

  const changeLanguage = (lang: string) => {
    const newLang = lang as Language
    setLanguage(newLang)
    loadTranslations(newLang)
    localStorage.setItem("language", newLang)
  }

  const t = (key: string, params?: Record<string, string>) => {
    let translation = translations[key] || key

    // Replace parameters in translation
    if (params) {
      Object.entries(params).forEach(([param, value]) => {
        translation = translation.replace(`{${param}}`, value)
      })
    }

    return translation
  }

  return <TranslationContext.Provider value={{ t, language, changeLanguage }}>{children}</TranslationContext.Provider>
}

// Hook to use translations
export function useTranslation() {
  const context = useContext(TranslationContext)
  if (context === undefined) {
    throw new Error("useTranslation must be used within a TranslationProvider")
  }
  return context
}

// Translation dictionaries
function getTranslations(language: Language): Record<string, string> {
  switch (language) {
    case "ru":
      return {
        // General
        save_changes: "Сохранить изменения",
        saving: "Сохранение...",
        cancel: "Отмена",
        update_failed: "Ошибка обновления",

        // Profile settings
        profile_settings: "Настройки профиля",
        profile_settings_desc: "Обновите информацию о себе",
        profile_updated: "Профиль обновлен",
        profile_update_success: "Ваш профиль был успешно обновлен",
        profile_update_error: "Не удалось обновить профиль. Пожалуйста, попробуйте снова.",
        avatar_requirements: "Рекомендуемый размер: 400x400 пикселей",
        display_name: "Отображаемое имя",
        display_name_placeholder: "Ваше имя",
        bio: "О себе",
        bio_placeholder: "Расскажите немного о себе...",
        website: "Веб-сайт",
        website_placeholder: "https://example.com",
        location: "Местоположение",
        location_placeholder: "Город, Страна",

        // Account settings
        username: "Имя пользователя",
        username_desc: "Ваше уникальное имя пользователя в Memerush",
        username_placeholder: "имя_пользователя",
        update_username: "Обновить имя пользователя",
        username_updated: "Имя пользователя обновлено",
        username_update_success: "Ваше имя пользователя было успешно обновлено",
        username_update_error: "Не удалось обновить имя пользователя. Возможно, оно уже занято.",

        email: "Электронная почта",
        email_desc: "Ваш адрес электронной почты для уведомлений и восстановления аккаунта",
        email_placeholder: "your@email.com",
        update_email: "Обновить email",
        email_updated: "Email обновлен",
        email_update_success: "Ваш email был успешно обновлен",
        email_update_error: "Не удалось обновить email. Пожалуйста, попробуйте снова.",

        password: "Пароль",
        password_desc: "Обновите свой пароль для повышения безопасности",
        current_password: "Текущий пароль",
        new_password: "Новый пароль",
        confirm_password: "Подтвердите пароль",
        update_password: "Обновить пароль",
        password_updated: "Пароль обновлен",
        password_update_success: "Ваш пароль был успешно обновлен",
        password_update_error: "Не удалось обновить пароль. Проверьте текущий пароль.",
        password_mismatch: "Пароли не совпадают",
        password_mismatch_desc: "Новый пароль и подтверждение должны совпадать",

        danger_zone: "Опасная зона",
        danger_zone_desc: "Действия, которые нельзя отменить",
        delete_account: "Удалить аккаунт",
        delete_account_warning: "Это действие нельзя отменить. Все ваши данные будут удалены навсегда.",
        delete_account_confirmation: "Подтвердите удаление аккаунта",
        delete_account_confirmation_desc:
          "Это действие нельзя отменить. Пожалуйста, введите ваше имя пользователя для подтверждения.",
        delete_account_type_username: "Введите '{username}' для подтверждения",
        confirm_delete: "Подтвердить удаление",
        deleting: "Удаление...",
        account_deleted: "Аккаунт удален",
        account_deleted_desc: "Ваш аккаунт был успешно удален",
        confirmation_error: "Ошибка подтверждения",
        username_confirmation_error: "Введенное имя пользователя не совпадает",
        delete_failed: "Ошибка удаления",
        account_delete_error: "Не удалось удалить аккаунт. Пожалуйста, попробуйте снова.",

        // Appearance settings
        appearance_settings: "Настройки внешнего вида",
        appearance_settings_desc: "Настройте тему и цвета приложения",
        theme: "Тема",
        light: "Светлая",
        dark: "Темная",
        system: "Системная",
        accent_color: "Акцентный цвет",
        purple: "Фиолетовый",
        blue: "Синий",
        green: "Зеленый",
        red: "Красный",
        orange: "Оранжевый",
        appearance_updated: "Внешний вид обновлен",
        appearance_update_success: "Настройки внешнего вида были успешно обновлены",
        appearance_update_error: "Не удалось обновить настройки внешнего вида",

        // Notification settings
        notification_settings: "Настройки уведомлений",
        notification_settings_desc: "Управляйте уведомлениями, которые вы получаете",
        notification_types: "Типы уведомлений",
        new_followers: "Новые подписчики",
        likes: "Лайки",
        comments: "Комментарии",
        mentions: "Упоминания",
        direct_messages: "Личные сообщения",
        new_content_from_following: "Новый контент от подписок",
        delivery_methods: "Способы доставки",
        email_notifications: "Email уведомления",
        push_notifications: "Push-уведомления",
        notifications_updated: "Уведомления обновлены",
        notifications_update_success: "Настройки уведомлений были успешно обновлены",
        notifications_update_error: "Не удалось обновить настройки уведомлений",

        // Privacy settings
        privacy_settings: "Настройки приватности",
        privacy_settings_desc: "Управляйте тем, кто может видеть ваш контент и взаимодействовать с вами",
        account_privacy: "Приватность аккаунта",
        private_account: "Приватный аккаунт",
        private_account_desc: "Только одобренные подписчики могут видеть ваш контент",
        show_activity: "Показывать активность",
        show_activity_desc: "Показывать вашу активность другим пользователям",
        interactions: "Взаимодействия",
        allow_tagging: "Разрешить отметки",
        allow_comments: "Разрешить комментарии",
        allow_direct_messages: "Разрешить личные сообщения",
        everyone: "Все",
        people_i_follow: "Люди, на которых я подписан",
        no_one: "Никто",
        data_and_personalization: "Данные и персонализация",
        data_personalization: "Персонализация данных",
        data_personalization_desc: "Разрешить использовать ваши данные для персонализации контента",
        privacy_updated: "Настройки приватности обновлены",
        privacy_update_success: "Настройки приватности были успешно обновлены",
        privacy_update_error: "Не удалось обновить настройки приватности",

        // Language settings
        language_settings: "Настройки языка",
        language_settings_desc: "Выберите предпочитаемый язык приложения",
        app_language: "Язык приложения",
        language_updated: "Язык обновлен",
        language_update_success: "Язык приложения был успешно обновлен",
        language_update_error: "Не удалось обновить язык приложения",
      }
    case "es":
      return {
        // General
        save_changes: "Guardar cambios",
        saving: "Guardando...",
        cancel: "Cancelar",
        update_failed: "Error de actualización",

        // Profile settings
        profile_settings: "Configuración de perfil",
        profile_settings_desc: "Actualiza tu información personal",
        profile_updated: "Perfil actualizado",
        profile_update_success: "Tu perfil ha sido actualizado con éxito",
        profile_update_error: "No se pudo actualizar el perfil. Por favor, inténtalo de nuevo.",
        avatar_requirements: "Tamaño recomendado: 400x400 píxeles",
        display_name: "Nombre para mostrar",
        display_name_placeholder: "Tu nombre",
        bio: "Biografía",
        bio_placeholder: "Cuéntanos un poco sobre ti...",
        website: "Sitio web",
        website_placeholder: "https://ejemplo.com",
        location: "Ubicación",
        location_placeholder: "Ciudad, País",

        // Account settings
        username: "Nombre de usuario",
        username_desc: "Tu nombre de usuario único en Memerush",
        username_placeholder: "nombre_usuario",
        update_username: "Actualizar nombre de usuario",
        username_updated: "Nombre de usuario actualizado",
        username_update_success: "Tu nombre de usuario ha sido actualizado con éxito",
        username_update_error: "No se pudo actualizar el nombre de usuario. Es posible que ya esté en uso.",

        email: "Correo electrónico",
        email_desc: "Tu dirección de correo electrónico para notificaciones y recuperación de cuenta",
        email_placeholder: "tu@email.com",
        update_email: "Actualizar email",
        email_updated: "Email actualizado",
        email_update_success: "Tu email ha sido actualizado con éxito",
        email_update_error: "No se pudo actualizar el email. Por favor, inténtalo de nuevo.",

        password: "Contraseña",
        password_desc: "Actualiza tu contraseña para mejorar la seguridad",
        current_password: "Contraseña actual",
        new_password: "Nueva contraseña",
        confirm_password: "Confirmar contraseña",
        update_password: "Actualizar contraseña",
        password_updated: "Contraseña actualizada",
        password_update_success: "Tu contraseña ha sido actualizada con éxito",
        password_update_error: "No se pudo actualizar la contraseña. Verifica tu contraseña actual.",
        password_mismatch: "Las contraseñas no coinciden",
        password_mismatch_desc: "La nueva contraseña y la confirmación deben coincidir",

        danger_zone: "Zona de peligro",
        danger_zone_desc: "Acciones que no se pueden deshacer",
        delete_account: "Eliminar cuenta",
        delete_account_warning: "Esta acción no se puede deshacer. Todos tus datos serán eliminados permanentemente.",
        delete_account_confirmation: "Confirmar eliminación de cuenta",
        delete_account_confirmation_desc:
          "Esta acción no se puede deshacer. Por favor, ingresa tu nombre de usuario para confirmar.",
        delete_account_type_username: "Escribe '{username}' para confirmar",
        confirm_delete: "Confirmar eliminación",
        deleting: "Eliminando...",
        account_deleted: "Cuenta eliminada",
        account_deleted_desc: "Tu cuenta ha sido eliminada con éxito",
        confirmation_error: "Error de confirmación",
        username_confirmation_error: "El nombre de usuario ingresado no coincide",
        delete_failed: "Error al eliminar",
        account_delete_error: "No se pudo eliminar la cuenta. Por favor, inténtalo de nuevo.",

        // Appearance settings
        appearance_settings: "Configuración de apariencia",
        appearance_settings_desc: "Personaliza el tema y los colores de la aplicación",
        theme: "Tema",
        light: "Claro",
        dark: "Oscuro",
        system: "Sistema",
        accent_color: "Color de acento",
        purple: "Morado",
        blue: "Azul",
        green: "Verde",
        red: "Rojo",
        orange: "Naranja",
        appearance_updated: "Apariencia actualizada",
        appearance_update_success: "La configuración de apariencia ha sido actualizada con éxito",
        appearance_update_error: "No se pudo actualizar la configuración de apariencia",

        // Notification settings
        notification_settings: "Configuración de notificaciones",
        notification_settings_desc: "Administra las notificaciones que recibes",
        notification_types: "Tipos de notificaciones",
        new_followers: "Nuevos seguidores",
        likes: "Me gusta",
        comments: "Comentarios",
        mentions: "Menciones",
        direct_messages: "Mensajes directos",
        new_content_from_following: "Nuevo contenido de seguidos",
        delivery_methods: "Métodos de entrega",
        email_notifications: "Notificaciones por email",
        push_notifications: "Notificaciones push",
        notifications_updated: "Notificaciones actualizadas",
        notifications_update_success: "La configuración de notificaciones ha sido actualizada con éxito",
        notifications_update_error: "No se pudo actualizar la configuración de notificaciones",

        // Privacy settings
        privacy_settings: "Configuración de privacidad",
        privacy_settings_desc: "Controla quién puede ver tu contenido e interactuar contigo",
        account_privacy: "Privacidad de la cuenta",
        private_account: "Cuenta privada",
        private_account_desc: "Solo los seguidores aprobados pueden ver tu contenido",
        show_activity: "Mostrar actividad",
        show_activity_desc: "Mostrar tu actividad a otros usuarios",
        interactions: "Interacciones",
        allow_tagging: "Permitir etiquetas",
        allow_comments: "Permitir comentarios",
        allow_direct_messages: "Permitir mensajes directos",
        everyone: "Todos",
        people_i_follow: "Personas que sigo",
        no_one: "Nadie",
        data_and_personalization: "Datos y personalización",
        data_personalization: "Personalización de datos",
        data_personalization_desc: "Permitir el uso de tus datos para personalizar el contenido",
        privacy_updated: "Privacidad actualizada",
        privacy_update_success: "La configuración de privacidad ha sido actualizada con éxito",
        privacy_update_error: "No se pudo actualizar la configuración de privacidad",

        // Language settings
        language_settings: "Configuración de idioma",
        language_settings_desc: "Elige el idioma preferido para la aplicación",
        app_language: "Idioma de la aplicación",
        language_updated: "Idioma actualizado",
        language_update_success: "El idioma de la aplicación ha sido actualizado con éxito",
        language_update_error: "No se pudo actualizar el idioma de la aplicación",
      }
    default:
      return {
        // General
        save_changes: "Save Changes",
        saving: "Saving...",
        cancel: "Cancel",
        update_failed: "Update Failed",

        // Profile settings
        profile_settings: "Profile Settings",
        profile_settings_desc: "Update your personal information",
        profile_updated: "Profile Updated",
        profile_update_success: "Your profile has been updated successfully",
        profile_update_error: "Failed to update profile. Please try again.",
        avatar_requirements: "Recommended size: 400x400 pixels",
        display_name: "Display Name",
        display_name_placeholder: "Your name",
        bio: "Bio",
        bio_placeholder: "Tell us a bit about yourself...",
        website: "Website",
        website_placeholder: "https://example.com",
        location: "Location",
        location_placeholder: "City, Country",

        // Account settings
        username: "Username",
        username_desc: "Your unique username on Memerush",
        username_placeholder: "username",
        update_username: "Update Username",
        username_updated: "Username Updated",
        username_update_success: "Your username has been updated successfully",
        username_update_error: "Failed to update username. It may already be taken.",

        email: "Email",
        email_desc: "Your email address for notifications and account recovery",
        email_placeholder: "your@email.com",
        update_email: "Update Email",
        email_updated: "Email Updated",
        email_update_success: "Your email has been updated successfully",
        email_update_error: "Failed to update email. Please try again.",

        password: "Password",
        password_desc: "Update your password to improve security",
        current_password: "Current Password",
        new_password: "New Password",
        confirm_password: "Confirm Password",
        update_password: "Update Password",
        password_updated: "Password Updated",
        password_update_success: "Your password has been updated successfully",
        password_update_error: "Failed to update password. Check your current password.",
        password_mismatch: "Passwords don't match",
        password_mismatch_desc: "New password and confirmation must match",

        // Danger Zone
        danger_zone: "Danger Zone",
        danger_zone_desc: "Actions that cannot be undone",
        delete_account: "Delete Account",
        delete_account_warning: "This action cannot be undone. All of your data will be permanently deleted.",
        delete_account_confirmation: "Confirm Account Deletion",
        delete_account_confirmation_desc: "This action cannot be undone. Please type your username to confirm.",
        delete_account_type_username: "Type '{username}' to confirm",
        confirm_delete: "Confirm Deletion",
        deleting: "Deleting...",
        account_deleted: "Account Deleted",
        account_deleted_desc: "Your account has been successfully deleted",
        confirmation_error: "Confirmation Error",
        username_confirmation_error: "The username you entered doesn't match",
        delete_failed: "Delete Failed",
        account_delete_error: "Failed to delete account. Please try again.",

        // Appearance settings
        appearance_settings: "Appearance Settings",
        appearance_settings_desc: "Customize the theme and colors of the app",
        theme: "Theme",
        light: "Light",
        dark: "Dark",
        system: "System",
        accent_color: "Accent Color",
        purple: "Purple",
        blue: "Blue",
        green: "Green",
        red: "Red",
        orange: "Orange",
        appearance_updated: "Appearance Updated",
        appearance_update_success: "Your appearance settings have been updated successfully",
        appearance_update_error: "Failed to update appearance settings",

        // Notification settings
        notification_settings: "Notification Settings",
        notification_settings_desc: "Manage the notifications you receive",
        notification_types: "Notification Types",
        new_followers: "New Followers",
        likes: "Likes",
        comments: "Comments",
        mentions: "Mentions",
        direct_messages: "Direct Messages",
        new_content_from_following: "New Content from Following",
        delivery_methods: "Delivery Methods",
        email_notifications: "Email Notifications",
        push_notifications: "Push Notifications",
        notifications_updated: "Notifications Updated",
        notifications_update_success: "Your notification settings have been updated successfully",
        notifications_update_error: "Failed to update notification settings",

        // Privacy settings
        privacy_settings: "Privacy Settings",
        privacy_settings_desc: "Control who can see your content and interact with you",
        account_privacy: "Account Privacy",
        private_account: "Private Account",
        private_account_desc: "Only approved followers can see your content",
        show_activity: "Show Activity",
        show_activity_desc: "Show your activity to other users",
        interactions: "Interactions",
        allow_tagging: "Allow Tagging",
        allow_comments: "Allow Comments",
        allow_direct_messages: "Allow Direct Messages",
        everyone: "Everyone",
        people_i_follow: "People I Follow",
        no_one: "No One",
        data_and_personalization: "Data & Personalization",
        data_personalization: "Data Personalization",
        data_personalization_desc: "Allow your data to be used for content personalization",
        privacy_updated: "Privacy Updated",
        privacy_update_success: "Your privacy settings have been updated successfully",
        privacy_update_error: "Failed to update privacy settings",

        // Language settings
        language_settings: "Language Settings",
        language_settings_desc: "Choose your preferred language for the app",
        app_language: "App Language",
        language_updated: "Language Updated",
        language_update_success: "Your app language has been updated successfully",
        language_update_error: "Failed to update app language",
      }
  }
}
