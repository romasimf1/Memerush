import type { ScheduledPost, Draft } from "@/types/content"
import { getCurrentUser } from "./auth"

// Mock scheduled posts for MVP
const mockScheduledPosts: ScheduledPost[] = [
  {
    id: "post1",
    mediaType: "image",
    mediaSrc: "/placeholder.svg?height=64&width=64&text=Scheduled+1",
    description: "When the code finally works after 5 hours #programming #debugging",
    scheduledFor: new Date(Date.now() + 1000 * 60 * 60 * 24).toISOString(), // Tomorrow
    platforms: ["memerush", "instagram"],
    tags: ["programming", "debugging", "meme"],
    status: "scheduled",
    createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(), // 1 hour ago
  },
  {
    id: "post2",
    mediaType: "image",
    mediaSrc: "/placeholder.svg?height=64&width=64&text=Scheduled+2",
    description: "Monday motivation meme #mondaymotivation",
    scheduledFor: new Date(Date.now() + 1000 * 60 * 60 * 48).toISOString(), // 2 days from now
    platforms: ["memerush", "twitter"],
    tags: ["monday", "motivation", "meme"],
    status: "scheduled",
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(), // 2 hours ago
  },
  {
    id: "post3",
    mediaType: "video",
    mediaSrc: "/placeholder.svg?height=64&width=64&text=Scheduled+3",
    description: "Weekend vibes #weekend #relax",
    scheduledFor: new Date(Date.now() + 1000 * 60 * 60 * 72).toISOString(), // 3 days from now
    platforms: ["memerush", "instagram", "twitter"],
    tags: ["weekend", "relax", "meme"],
    status: "paused",
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(), // 3 hours ago
  },
]

// Mock drafts for MVP
const mockDrafts: Draft[] = [
  {
    id: "draft1",
    mediaType: "image",
    mediaSrc: "/placeholder.svg?height=64&width=64&text=Draft+1",
    description: "Work in progress meme about remote work",
    platforms: ["memerush", "instagram"],
    tags: ["remotework", "wfh", "meme"],
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(), // 12 hours ago
  },
  {
    id: "draft2",
    mediaType: "video",
    mediaSrc: "/placeholder.svg?height=64&width=64&text=Draft+2",
    description: "",
    platforms: ["memerush"],
    tags: [],
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(), // 2 days ago
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
  },
]

// Get scheduled posts
export const getScheduledPosts = async (): Promise<ScheduledPost[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  return [...mockScheduledPosts]
}

// Get drafts
export const getDrafts = async (): Promise<Draft[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  return [...mockDrafts]
}

// Schedule a post
export interface SchedulePostParams {
  media: File | null
  description: string
  scheduledFor: Date
  platforms: string[]
  tags: string[]
}

export const schedulePost = async (params: SchedulePostParams): Promise<ScheduledPost> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1500))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would upload to Cloudinary or similar
  // For MVP, we'll just create a mock scheduled post
  const newPost: ScheduledPost = {
    id: `post-${Date.now()}`,
    mediaType: params.media?.type.startsWith("video/") ? "video" : "image",
    // In a real app, this would be the URL from Cloudinary
    mediaSrc: params.media ? URL.createObjectURL(params.media) : "/placeholder.svg?height=64&width=64&text=New+Post",
    description: params.description,
    scheduledFor: params.scheduledFor.toISOString(),
    platforms: params.platforms,
    tags: params.tags,
    status: "scheduled",
    createdAt: new Date().toISOString(),
  }

  // In a real app, this would be saved to a database
  mockScheduledPosts.unshift(newPost)

  return newPost
}

// Save a draft
export interface SaveDraftParams {
  media: File | null
  description: string
  platforms: string[]
  tags: string[]
}

export const saveDraft = async (params: SaveDraftParams): Promise<Draft> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would upload to Cloudinary or similar
  // For MVP, we'll just create a mock draft
  const newDraft: Draft = {
    id: `draft-${Date.now()}`,
    mediaType: params.media?.type.startsWith("video/") ? "video" : "image",
    // In a real app, this would be the URL from Cloudinary
    mediaSrc: params.media ? URL.createObjectURL(params.media) : "/placeholder.svg?height=64&width=64&text=New+Draft",
    description: params.description,
    platforms: params.platforms,
    tags: params.tags,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  // In a real app, this would be saved to a database
  mockDrafts.unshift(newDraft)

  return newDraft
}
