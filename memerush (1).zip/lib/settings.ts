import type { UserSettings } from "@/types/settings"
import { getCurrentUser } from "./auth"

// Mock user settings
let mockUserSettings: UserSettings = {
  username: "demouser",
  displayName: "Demo User",
  email: "user@example.com",
  bio: "Just here for the memes!",
  avatar: "/placeholder.svg?height=200&width=200",
  theme: "dark",
  accentColor: "purple",
  language: "en",
  notifications: {
    newFollowers: true,
    likes: true,
    comments: true,
    mentions: true,
    directMessages: true,
    newContent: false,
    emailNotifications: true,
    pushNotifications: true,
  },
  privacy: {
    privateAccount: false,
    showActivity: true,
    allowTagging: "everyone",
    allowComments: "everyone",
    allowDirectMessages: "everyone",
    dataPersonalization: true,
  },
}

// Get user settings
export const getUserSettings = async (): Promise<UserSettings> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would fetch from a database
  return { ...mockUserSettings }
}

// Update profile
export const updateProfile = async (profileData: {
  displayName: string
  bio: string
  website?: string
  location?: string
  avatar?: File | null
}): Promise<Partial<UserSettings>> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1200))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would update the database
  mockUserSettings = {
    ...mockUserSettings,
    displayName: profileData.displayName,
    bio: profileData.bio,
    website: profileData.website,
    location: profileData.location,
    // In a real app, the avatar would be uploaded to a storage service
    // and the URL would be returned
    avatar: profileData.avatar ? URL.createObjectURL(profileData.avatar) : mockUserSettings.avatar,
  }

  return {
    displayName: mockUserSettings.displayName,
    bio: mockUserSettings.bio,
    website: mockUserSettings.website,
    location: mockUserSettings.location,
    avatar: mockUserSettings.avatar,
  }
}

// Update username
export const updateUsername = async (username: string): Promise<Partial<UserSettings>> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // Check if username is already taken
  if (username !== mockUserSettings.username && Math.random() > 0.8) {
    throw new Error("Username already taken")
  }

  // In a real app, this would update the database
  mockUserSettings = {
    ...mockUserSettings,
    username,
  }

  return {
    username: mockUserSettings.username,
  }
}

// Update email
export const updateEmail = async (email: string): Promise<Partial<UserSettings>> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would update the database
  mockUserSettings = {
    ...mockUserSettings,
    email,
  }

  return {
    email: mockUserSettings.email,
  }
}

// Update password
export const updatePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1500))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would verify the current password and update the database
  if (currentPassword !== "password123") {
    throw new Error("Current password is incorrect")
  }

  // Password updated successfully
}

// Delete account
export const deleteAccount = async (): Promise<void> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 2000))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would delete the user from the database
  // For demo purposes, we'll just simulate success
}

// Update appearance settings
export const updateAppearance = async (appearanceData: {
  theme: "light" | "dark" | "system"
  accentColor: string
}): Promise<Partial<UserSettings>> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would update the database
  mockUserSettings = {
    ...mockUserSettings,
    theme: appearanceData.theme,
    accentColor: appearanceData.accentColor,
  }

  return {
    theme: mockUserSettings.theme,
    accentColor: mockUserSettings.accentColor,
  }
}

// Update notification settings
export const updateNotificationSettings = async (notificationSettings: {
  newFollowers: boolean
  likes: boolean
  comments: boolean
  mentions: boolean
  directMessages: boolean
  newContent: boolean
  emailNotifications: boolean
  pushNotifications: boolean
}): Promise<Partial<UserSettings>> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would update the database
  mockUserSettings = {
    ...mockUserSettings,
    notifications: notificationSettings,
  }

  return {
    notifications: mockUserSettings.notifications,
  }
}

// Update privacy settings
export const updatePrivacySettings = async (privacySettings: {
  privateAccount: boolean
  showActivity: boolean
  allowTagging: string
  allowComments: string
  allowDirectMessages: string
  dataPersonalization: boolean
}): Promise<Partial<UserSettings>> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would update the database
  mockUserSettings = {
    ...mockUserSettings,
    privacy: privacySettings,
  }

  return {
    privacy: mockUserSettings.privacy,
  }
}

// Update language settings
export const updateLanguageSettings = async (languageSettings: {
  language: string
}): Promise<Partial<UserSettings>> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  const currentUser = getCurrentUser()
  if (!currentUser) {
    throw new Error("Not authenticated")
  }

  // In a real app, this would update the database
  mockUserSettings = {
    ...mockUserSettings,
    language: languageSettings.language,
  }

  return {
    language: mockUserSettings.language,
  }
}
