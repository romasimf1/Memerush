import type { Campaign } from "@/types/campaign"

// Mock campaigns for MVP
const mockCampaigns: Campaign[] = [
  {
    id: "campaign1",
    name: "Summer Meme Contest",
    status: "active",
    goal: "Increase engagement",
    startDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(), // 7 days ago
    endDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(), // 7 days from now
    budget: 500,
    reach: 25000,
    engagementRate: 4.8,
    conversionRate: 2.3,
    performance: "Above average",
    progress: 50,
  },
  {
    id: "campaign2",
    name: "Back to School Memes",
    status: "scheduled",
    goal: "Brand awareness",
    startDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14).toISOString(), // 14 days from now
    endDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 28).toISOString(), // 28 days from now
    budget: 750,
    reach: 0,
    engagementRate: 0,
    conversionRate: 0,
    performance: "Not started",
    progress: 0,
  },
  {
    id: "campaign3",
    name: "Spring Meme Collection",
    status: "completed",
    goal: "Content promotion",
    startDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 60).toISOString(), // 60 days ago
    endDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(), // 30 days ago
    budget: 600,
    reach: 35000,
    engagementRate: 5.2,
    conversionRate: 2.8,
    performance: "Excellent",
    progress: 100,
  },
  {
    id: "campaign4",
    name: "Holiday Meme Special",
    status: "scheduled",
    goal: "Sales conversion",
    startDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 60).toISOString(), // 60 days from now
    endDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 90).toISOString(), // 90 days from now
    budget: 1000,
    reach: 0,
    engagementRate: 0,
    conversionRate: 0,
    performance: "Not started",
    progress: 0,
  },
]

// Get campaigns
export const getCampaigns = async (): Promise<Campaign[]> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 800))

  return [...mockCampaigns]
}
