import type { AnalyticsData, Activity, TopContent } from "@/types/analytics"

// Mock analytics data for MVP
export const getAnalyticsData = async (timeRange: "7d" | "30d" | "90d"): Promise<AnalyticsData> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Generate mock data based on time range
  const multiplier = timeRange === "7d" ? 1 : timeRange === "30d" ? 4 : 12

  // Mock performance data for line chart
  const labels =
    timeRange === "7d"
      ? ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
      : Array.from({ length: 10 }, (_, i) => `Day ${i + 1}`)

  const performanceData = {
    labels,
    datasets: [
      {
        label: "Views",
        data: Array.from({ length: labels.length }, () => Math.floor(Math.random() * 1000 * multiplier)),
        borderColor: "rgb(99, 102, 241)",
        backgroundColor: "rgba(99, 102, 241, 0.5)",
      },
      {
        label: "Likes",
        data: Array.from({ length: labels.length }, () => Math.floor(Math.random() * 200 * multiplier)),
        borderColor: "rgb(239, 68, 68)",
        backgroundColor: "rgba(239, 68, 68, 0.5)",
      },
      {
        label: "Comments",
        data: Array.from({ length: labels.length }, () => Math.floor(Math.random() * 50 * multiplier)),
        borderColor: "rgb(16, 185, 129)",
        backgroundColor: "rgba(16, 185, 129, 0.5)",
      },
    ],
  }

  // Mock demographics data for pie chart
  const demographicsData = {
    labels: ["18-24", "25-34", "35-44", "45-54", "55+"],
    datasets: [
      {
        label: "Age Groups",
        data: [35, 40, 15, 7, 3],
        backgroundColor: [
          "rgba(99, 102, 241, 0.7)",
          "rgba(79, 70, 229, 0.7)",
          "rgba(67, 56, 202, 0.7)",
          "rgba(55, 48, 163, 0.7)",
          "rgba(49, 46, 129, 0.7)",
        ],
        borderWidth: 1,
      },
    ],
  }

  // Mock audience data for bar chart
  const audienceData = {
    labels: ["Direct", "Explore", "Search", "Hashtags", "Profile", "Other"],
    datasets: [
      {
        label: "Traffic Sources",
        data: [35, 25, 15, 10, 10, 5],
        backgroundColor: "rgba(99, 102, 241, 0.7)",
      },
    ],
  }

  // Mock top performing content
  const topContent: TopContent[] = [
    {
      id: "content1",
      title: "When the code finally works after 5 hours",
      thumbnail: "/placeholder.svg?height=64&width=64&text=Meme+1",
      performance: "+128%",
      likes: 1200 * multiplier,
      comments: 85 * multiplier,
      shares: 320 * multiplier,
    },
    {
      id: "content2",
      title: "Monday morning vibes",
      thumbnail: "/placeholder.svg?height=64&width=64&text=Meme+2",
      performance: "+95%",
      likes: 950 * multiplier,
      comments: 62 * multiplier,
      shares: 210 * multiplier,
    },
    {
      id: "content3",
      title: "When someone asks if I'm productive working from home",
      thumbnail: "/placeholder.svg?height=64&width=64&text=Meme+3",
      performance: "+76%",
      likes: 820 * multiplier,
      comments: 45 * multiplier,
      shares: 180 * multiplier,
    },
  ]

  // Mock recent activities
  const recentActivities: Activity[] = [
    {
      id: "activity1",
      type: "like",
      username: "memer42",
      timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(), // 5 minutes ago
      content: "",
    },
    {
      id: "activity2",
      type: "comment",
      username: "laughalot",
      timestamp: new Date(Date.now() - 1000 * 60 * 15).toISOString(), // 15 minutes ago
      content: "This is hilarious! 😂",
    },
    {
      id: "activity3",
      type: "follow",
      username: "memequeen",
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutes ago
      content: "",
    },
    {
      id: "activity4",
      type: "share",
      username: "viralking",
      timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(), // 45 minutes ago
      content: "",
    },
    {
      id: "activity5",
      type: "comment",
      username: "user123",
      timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(), // 1 hour ago
      content: "I can't stop laughing at this!",
    },
  ]

  // Mock scheduled posts
  const scheduledPosts = [
    {
      id: "post1",
      description: "New meme about programming struggles",
      scheduledFor: new Date(Date.now() + 1000 * 60 * 60 * 24).toISOString(), // Tomorrow
      platforms: ["memerush", "instagram"],
    },
    {
      id: "post2",
      description: "Monday motivation meme",
      scheduledFor: new Date(Date.now() + 1000 * 60 * 60 * 48).toISOString(), // 2 days from now
      platforms: ["memerush", "twitter"],
    },
    {
      id: "post3",
      description: "Weekend vibes",
      scheduledFor: new Date(Date.now() + 1000 * 60 * 60 * 72).toISOString(), // 3 days from now
      platforms: ["memerush", "instagram", "twitter"],
    },
  ]

  return {
    totalViews: 25000 * multiplier,
    viewsChange: 12,
    engagementRate: 4.8,
    engagementChange: 0.5,
    newFollowers: 450 * multiplier,
    followersChange: 15,
    conversionRate: 2.3,
    conversionChange: 0.2,
    performanceData,
    demographicsData,
    audienceData,
    topContent,
    recentActivities,
    scheduledPosts,
  }
}
