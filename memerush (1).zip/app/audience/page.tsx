"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { AudienceSegmentsList } from "@/components/audience/audience-segments-list"
import { AudienceInsights } from "@/components/audience/audience-insights"
import { FollowersList } from "@/components/audience/followers-list"
import { useToast } from "@/components/ui/use-toast"
import { checkAuth } from "@/lib/auth"
import { getAudienceData, getFollowers, getAudienceSegments } from "@/lib/audience"
import type { AudienceData, Follower, AudienceSegment } from "@/types/audience"

export default function AudiencePage() {
  const router = useRouter()
  const { toast } = useToast()
  const [audienceData, setAudienceData] = useState<AudienceData | null>(null)
  const [followers, setFollowers] = useState<Follower[]>([])
  const [segments, setSegments] = useState<AudienceSegment[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const init = async () => {
      try {
        // Check if user is authenticated
        const isAuthenticated = await checkAuth()
        if (!isAuthenticated) {
          router.push("/login")
          return
        }

        // Fetch audience data
        const data = await getAudienceData()
        setAudienceData(data)

        // Fetch followers
        const followersData = await getFollowers()
        setFollowers(followersData)

        // Fetch audience segments
        const segmentsData = await getAudienceSegments()
        setSegments(segmentsData)
      } catch (error) {
        console.error("Failed to load audience data:", error)
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load audience data. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    init()
  }, [router, toast])

  const filteredFollowers = followers.filter(
    (follower) =>
      follower.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      follower.displayName.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (!audienceData) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4 text-center">
        <h1 className="mb-4 text-2xl font-bold">Audience Data Unavailable</h1>
        <p className="mb-8 text-muted-foreground">We couldn&apos;t load your audience data. Please try again later.</p>
        <Button onClick={() => router.push("/dashboard")}>Back to Dashboard</Button>
      </div>
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Audience Manager" text="Understand and segment your audience for targeted campaigns.">
        <Button onClick={() => router.push("/audience/create-segment")}>Create Segment</Button>
      </DashboardHeader>

      <Tabs defaultValue="insights" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="insights">Audience Insights</TabsTrigger>
          <TabsTrigger value="followers">Followers ({followers.length})</TabsTrigger>
          <TabsTrigger value="segments">Segments ({segments.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Followers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{audienceData.totalFollowers.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  {audienceData.followerGrowth > 0 ? "+" : ""}
                  {audienceData.followerGrowth}% from last month
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg. Engagement</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{audienceData.avgEngagement}%</div>
                <p className="text-xs text-muted-foreground">
                  {audienceData.engagementChange > 0 ? "+" : ""}
                  {audienceData.engagementChange}% from last month
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Followers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{audienceData.activeFollowers}%</div>
                <p className="text-xs text-muted-foreground">Of total audience in last 30 days</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Audience Reach</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{audienceData.reach.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">Unique viewers in last 30 days</p>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Audience Insights</CardTitle>
              <CardDescription>Detailed breakdown of your audience</CardDescription>
            </CardHeader>
            <CardContent>
              <AudienceInsights data={audienceData} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="followers" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Your Followers</CardTitle>
              <CardDescription>People following your content</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <Input
                  placeholder="Search followers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="max-w-sm"
                />
              </div>
              <FollowersList followers={filteredFollowers} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="segments" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Audience Segments</CardTitle>
              <CardDescription>Target specific groups with your campaigns</CardDescription>
            </CardHeader>
            <CardContent>
              <AudienceSegmentsList segments={segments} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}
