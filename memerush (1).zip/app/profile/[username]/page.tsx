"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { motion } from "framer-motion"
import { LogOut, Settings, Film, UserPlus, UserMinus, Bell, BellOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { BottomNav } from "@/components/bottom-nav"
import { getUserProfile, getUserMemes } from "@/lib/data"
import { checkAuth, logoutUser } from "@/lib/auth"
import { followUser, unfollowUser, toggleNotifications } from "@/lib/social"
import type { Meme } from "@/types/meme"
import type { User } from "@/types/user"

export default function ProfilePage({ params }: { params: { username: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const [user, setUser] = useState<User | null>(null)
  const [memes, setMemes] = useState<Meme[]>([])
  const [loading, setLoading] = useState(true)
  const [isCurrentUser, setIsCurrentUser] = useState(false)
  const [isFollowing, setIsFollowing] = useState(false)
  const [notificationsEnabled, setNotificationsEnabled] = useState(false)
  const [followLoading, setFollowLoading] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Check if user is authenticated
        const isAuthenticated = await checkAuth()
        if (!isAuthenticated) {
          router.push("/login")
          return
        }

        // Fetch user profile
        const userData = await getUserProfile(params.username)
        setUser(userData)

        // Check if this is the current user's profile
        setIsCurrentUser(userData.isCurrentUser)

        // Set following state
        setIsFollowing(userData.isFollowing || false)
        setNotificationsEnabled(userData.notificationsEnabled || false)

        // Fetch user's memes
        const memesData = await getUserMemes(params.username)
        setMemes(memesData)
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load profile. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [params.username, router, toast])

  const handleLogout = async () => {
    try {
      await logoutUser()
      router.push("/login")
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to log out. Please try again.",
      })
    }
  }

  const handleFollowToggle = async () => {
    if (!user) return

    setFollowLoading(true)

    try {
      if (isFollowing) {
        await unfollowUser(user.username)
        setIsFollowing(false)
        setNotificationsEnabled(false)

        // Update followers count
        if (user) {
          setUser({
            ...user,
            followers: user.followers - 1,
          })
        }

        toast({
          title: "Unfollowed",
          description: `You are no longer following @${user.username}`,
        })
      } else {
        await followUser(user.username)
        setIsFollowing(true)
        setNotificationsEnabled(true)

        // Update followers count
        if (user) {
          setUser({
            ...user,
            followers: user.followers + 1,
          })
        }

        toast({
          title: "Following",
          description: `You are now following @${user.username}`,
        })
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update follow status. Please try again.",
      })
    } finally {
      setFollowLoading(false)
    }
  }

  const handleNotificationsToggle = async () => {
    if (!user || !isFollowing) return

    try {
      await toggleNotifications(user.username, !notificationsEnabled)
      setNotificationsEnabled(!notificationsEnabled)

      toast({
        title: notificationsEnabled ? "Notifications disabled" : "Notifications enabled",
        description: notificationsEnabled
          ? `You will no longer receive notifications from @${user.username}`
          : `You will now receive notifications from @${user.username}`,
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update notification settings. Please try again.",
      })
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4 text-center">
        <h1 className="mb-4 text-2xl font-bold">User not found</h1>
        <p className="mb-8 text-muted-foreground">The user you're looking for doesn't exist.</p>
        <Button onClick={() => router.push("/feed")}>Back to Feed</Button>
        <BottomNav />
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-background pb-16">
      <div className="relative">
        {/* Banner */}
        <div className="h-32 w-full bg-gradient-to-r from-purple-500 to-pink-500" />

        {/* Profile picture */}
        <div className="absolute left-1/2 top-16 -translate-x-1/2 transform">
          <div className="relative h-24 w-24 overflow-hidden rounded-full border-4 border-background">
            <Image
              src={user.avatar || "/placeholder.svg?height=96&width=96"}
              alt={user.username}
              fill
              className="object-cover"
            />
          </div>
        </div>
      </div>

      {/* Profile info */}
      <div className="mt-16 flex flex-col items-center p-4 text-center">
        <h1 className="text-2xl font-bold">{user.displayName}</h1>
        <p className="text-muted-foreground">@{user.username}</p>

        {user.bio && <p className="mt-2 max-w-md text-sm">{user.bio}</p>}

        <div className="mt-4 flex gap-4">
          <div className="text-center">
            <p className="font-bold">{memes.length}</p>
            <p className="text-xs text-muted-foreground">Memes</p>
          </div>
          <div
            className="text-center cursor-pointer"
            onClick={() => router.push(`/profile/${user.username}/followers`)}
          >
            <p className="font-bold">{user.followers}</p>
            <p className="text-xs text-muted-foreground">Followers</p>
          </div>
          <div
            className="text-center cursor-pointer"
            onClick={() => router.push(`/profile/${user.username}/following`)}
          >
            <p className="font-bold">{user.following}</p>
            <p className="text-xs text-muted-foreground">Following</p>
          </div>
        </div>

        {isCurrentUser ? (
          <div className="mt-4 flex gap-2">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Settings className="h-4 w-4" />
              Edit Profile
            </Button>
            <Button variant="destructive" size="sm" className="flex items-center gap-1" onClick={handleLogout}>
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        ) : (
          <div className="mt-4 flex gap-2">
            <Button
              className="flex items-center gap-1"
              variant={isFollowing ? "outline" : "default"}
              size="sm"
              onClick={handleFollowToggle}
              disabled={followLoading}
            >
              {followLoading ? (
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
              ) : isFollowing ? (
                <UserMinus className="h-4 w-4" />
              ) : (
                <UserPlus className="h-4 w-4" />
              )}
              {isFollowing ? "Unfollow" : "Follow"}
            </Button>

            {isFollowing && (
              <Button variant="ghost" size="sm" className="flex items-center gap-1" onClick={handleNotificationsToggle}>
                {notificationsEnabled ? (
                  <>
                    <BellOff className="h-4 w-4" />
                    Mute
                  </>
                ) : (
                  <>
                    <Bell className="h-4 w-4" />
                    Notify
                  </>
                )}
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Memes grid */}
      <div className="mt-6 p-4">
        <h2 className="mb-4 text-lg font-semibold">Memes</h2>
        {memes.length > 0 ? (
          <div className="grid grid-cols-3 gap-1">
            {memes.map((meme) => (
              <motion.div
                key={meme.id}
                whileHover={{ scale: 1.02 }}
                className="aspect-square cursor-pointer overflow-hidden"
                onClick={() => router.push(`/feed?meme=${meme.id}`)}
              >
                {meme.type === "video" ? (
                  <div className="relative h-full w-full">
                    <video src={meme.src} className="h-full w-full object-cover" muted playsInline />
                    <div className="absolute bottom-1 right-1">
                      <Film className="h-4 w-4 text-white drop-shadow-md" />
                    </div>
                  </div>
                ) : (
                  <Image
                    src={meme.src || "/placeholder.svg"}
                    alt={meme.description || "Meme"}
                    fill
                    className="object-cover"
                    unoptimized
                  />
                )}
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center rounded-lg bg-muted/50 p-8 text-center">
            <p className="mb-2 text-lg font-medium">No memes yet</p>
            <p className="mb-4 text-sm text-muted-foreground">
              {isCurrentUser ? "Upload your first meme!" : "This user hasn't posted any memes yet."}
            </p>
            {isCurrentUser && (
              <Button variant="outline" onClick={() => router.push("/upload")}>
                Upload a Meme
              </Button>
            )}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  )
}
