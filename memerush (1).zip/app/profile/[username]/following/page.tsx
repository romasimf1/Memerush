"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { ArrowLeft, Search, UserPlus, UserMinus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { BottomNav } from "@/components/bottom-nav"
import { getUserFollowing } from "@/lib/social"
import { checkAuth } from "@/lib/auth"
import { followUser, unfollowUser } from "@/lib/social"
import type { FollowerUser } from "@/types/user"

export default function FollowingPage({ params }: { params: { username: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const [following, setFollowing] = useState<FollowerUser[]>([])
  const [filteredFollowing, setFilteredFollowing] = useState<FollowerUser[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Check if user is authenticated
        const isAuthenticated = await checkAuth()
        if (!isAuthenticated) {
          router.push("/login")
          return
        }

        // Fetch following
        const followingData = await getUserFollowing(params.username)
        setFollowing(followingData)
        setFilteredFollowing(followingData)
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load following. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [params.username, router, toast])

  useEffect(() => {
    // Filter following based on search query
    const filtered = following.filter(
      (user) =>
        user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.displayName.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    setFilteredFollowing(filtered)
  }, [searchQuery, following])

  const handleFollowToggle = async (username: string) => {
    try {
      // Find the user in the list
      const userIndex = following.findIndex((f) => f.username === username)
      if (userIndex === -1) return

      const user = following[userIndex]
      const isFollowing = user.isFollowing

      // Update UI optimistically
      const updatedFollowing = [...following]
      updatedFollowing[userIndex] = {
        ...user,
        isFollowing: !isFollowing,
      }
      setFollowing(updatedFollowing)

      // Make API call
      if (isFollowing) {
        await unfollowUser(username)
        toast({
          title: "Unfollowed",
          description: `You are no longer following @${username}`,
        })
      } else {
        await followUser(username)
        toast({
          title: "Following",
          description: `You are now following @${username}`,
        })
      }
    } catch (error) {
      // Revert on error
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update follow status. Please try again.",
      })
      // Refresh data
      const followingData = await getUserFollowing(params.username)
      setFollowing(followingData)
      setFilteredFollowing(
        followingData.filter(
          (user) =>
            user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
            user.displayName.toLowerCase().includes(searchQuery.toLowerCase()),
        ),
      )
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-background pb-16">
      <div className="sticky top-0 z-10 flex items-center justify-between border-b bg-background/80 p-4 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold">Following</h1>
        </div>
      </div>

      <div className="p-4">
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
          <Input
            placeholder="Search following..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="space-y-4">
          {filteredFollowing.length > 0 ? (
            filteredFollowing.map((user) => (
              <div key={user.username} className="flex items-center justify-between">
                <div
                  className="flex items-center gap-3 cursor-pointer"
                  onClick={() => router.push(`/profile/${user.username}`)}
                >
                  <div className="relative h-12 w-12 overflow-hidden rounded-full">
                    <Image
                      src={user.avatar || "/placeholder.svg?height=48&width=48"}
                      alt={user.displayName}
                      fill
                      className="object-cover"
                      unoptimized
                    />
                  </div>
                  <div>
                    <p className="font-medium">{user.displayName}</p>
                    <p className="text-sm text-muted-foreground">@{user.username}</p>
                  </div>
                </div>

                {!user.isCurrentUser && (
                  <Button
                    variant={user.isFollowing ? "outline" : "default"}
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => handleFollowToggle(user.username)}
                  >
                    {user.isFollowing ? (
                      <>
                        <UserMinus className="h-4 w-4" />
                        Unfollow
                      </>
                    ) : (
                      <>
                        <UserPlus className="h-4 w-4" />
                        Follow
                      </>
                    )}
                  </Button>
                )}
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <p className="text-lg font-medium">No following found</p>
              <p className="text-sm text-muted-foreground">
                {searchQuery ? "No users match your search." : `@${params.username} isn't following anyone yet.`}
              </p>
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
