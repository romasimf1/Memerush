"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { format } from "date-fns"
import { CalendarIcon, Clock, Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { MediaUploader } from "@/components/content/media-uploader"
import { ScheduledPostsList } from "@/components/content/scheduled-posts-list"
import { DraftsList } from "@/components/content/drafts-list"
import { useToast } from "@/components/ui/use-toast"
import { checkAuth } from "@/lib/auth"
import { getScheduledPosts, getDrafts, schedulePost, saveDraft } from "@/lib/content"
import type { ScheduledPost, Draft } from "@/types/content"

export default function SchedulePage() {
  const router = useRouter()
  const { toast } = useToast()
  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPost[]>([])
  const [drafts, setDrafts] = useState<Draft[]>([])
  const [loading, setLoading] = useState(true)
  const [file, setFile] = useState<File | null>(null)
  const [description, setDescription] = useState("")
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [time, setTime] = useState("12:00")
  const [platforms, setPlatforms] = useState<string[]>(["memerush"])
  const [tags, setTags] = useState<string[]>([])
  const [newTag, setNewTag] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    const init = async () => {
      try {
        // Check if user is authenticated
        const isAuthenticated = await checkAuth()
        if (!isAuthenticated) {
          router.push("/login")
          return
        }

        // Fetch scheduled posts and drafts
        const postsData = await getScheduledPosts()
        const draftsData = await getDrafts()
        setScheduledPosts(postsData)
        setDrafts(draftsData)
      } catch (error) {
        console.error("Failed to load content data:", error)
      } finally {
        setLoading(false)
      }
    }

    init()
  }, [router])

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()])
      setNewTag("")
    }
  }

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  const handleTogglePlatform = (platform: string) => {
    if (platforms.includes(platform)) {
      setPlatforms(platforms.filter((p) => p !== platform))
    } else {
      setPlatforms([...platforms, platform])
    }
  }

  const handleSchedulePost = async () => {
    if (!file) {
      toast({
        variant: "destructive",
        title: "No media selected",
        description: "Please select an image or video to schedule.",
      })
      return
    }

    if (!description.trim()) {
      toast({
        variant: "destructive",
        title: "Description required",
        description: "Please add a description for your post.",
      })
      return
    }

    if (!date) {
      toast({
        variant: "destructive",
        title: "Date required",
        description: "Please select a date for your scheduled post.",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Combine date and time
      const [hours, minutes] = time.split(":").map(Number)
      const scheduledDate = new Date(date)
      scheduledDate.setHours(hours, minutes)

      // Schedule the post
      const newPost = await schedulePost({
        media: file,
        description,
        scheduledFor: scheduledDate,
        platforms,
        tags,
      })

      setScheduledPosts([...scheduledPosts, newPost])

      // Reset form
      setFile(null)
      setDescription("")
      setDate(undefined)
      setTime("12:00")
      setPlatforms(["memerush"])
      setTags([])

      toast({
        title: "Post scheduled",
        description: `Your post has been scheduled for ${format(scheduledDate, "PPP 'at' p")}`,
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to schedule post",
        description: "There was an error scheduling your post. Please try again.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSaveDraft = async () => {
    if (!file && !description.trim()) {
      toast({
        variant: "destructive",
        title: "Empty draft",
        description: "Please add media or a description before saving as draft.",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Save as draft
      const newDraft = await saveDraft({
        media: file,
        description,
        platforms,
        tags,
      })

      setDrafts([...drafts, newDraft])

      // Reset form
      setFile(null)
      setDescription("")
      setDate(undefined)
      setTime("12:00")
      setPlatforms(["memerush"])
      setTags([])

      toast({
        title: "Draft saved",
        description: "Your draft has been saved successfully.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Failed to save draft",
        description: "There was an error saving your draft. Please try again.",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Content Scheduler" text="Create, schedule, and manage your content across platforms.">
        <Button onClick={() => router.push("/dashboard")}>View Analytics</Button>
      </DashboardHeader>

      <Tabs defaultValue="create" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="create">Create Post</TabsTrigger>
          <TabsTrigger value="scheduled">Scheduled ({scheduledPosts.length})</TabsTrigger>
          <TabsTrigger value="drafts">Drafts ({drafts.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="mt-4">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Create New Post</CardTitle>
                <CardDescription>Upload media and add details for your post</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="media">Media</Label>
                  <MediaUploader
                    file={file}
                    onFileChange={setFile}
                    accept="image/jpeg,image/png,video/mp4,video/webm"
                    maxSize={10 * 1024 * 1024} // 10MB
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Write your post description here..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="min-h-[120px]"
                  />
                  <p className="text-xs text-muted-foreground text-right">{description.length}/500</p>
                </div>

                <div className="space-y-2">
                  <Label>Tags</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {tags.map((tag) => (
                      <div
                        key={tag}
                        className="flex items-center bg-secondary text-secondary-foreground px-2 py-1 rounded-md text-sm"
                      >
                        #{tag}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-5 w-5 ml-1 text-muted-foreground hover:text-foreground"
                          onClick={() => handleRemoveTag(tag)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add a tag..."
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault()
                          handleAddTag()
                        }
                      }}
                    />
                    <Button type="button" size="sm" onClick={handleAddTag}>
                      <Plus className="h-4 w-4 mr-1" /> Add
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Platforms</Label>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant={platforms.includes("memerush") ? "default" : "outline"}
                      onClick={() => handleTogglePlatform("memerush")}
                      className="rounded-full"
                    >
                      Memerush
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant={platforms.includes("instagram") ? "default" : "outline"}
                      onClick={() => handleTogglePlatform("instagram")}
                      className="rounded-full"
                    >
                      Instagram
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant={platforms.includes("twitter") ? "default" : "outline"}
                      onClick={() => handleTogglePlatform("twitter")}
                      className="rounded-full"
                    >
                      Twitter
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant={platforms.includes("tiktok") ? "default" : "outline"}
                      onClick={() => handleTogglePlatform("tiktok")}
                      className="rounded-full"
                    >
                      TikTok
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Schedule Settings</CardTitle>
                <CardDescription>Set when your post should be published</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Publication Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : "Select a date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <Label>Publication Time</Label>
                  <div className="flex items-center">
                    <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                    <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Optimization</Label>
                  <Select defaultValue="auto">
                    <SelectTrigger>
                      <SelectValue placeholder="Select optimization" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto (Best Time)</SelectItem>
                      <SelectItem value="engagement">Optimize for Engagement</SelectItem>
                      <SelectItem value="reach">Optimize for Reach</SelectItem>
                      <SelectItem value="conversion">Optimize for Conversion</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={handleSaveDraft} disabled={isSubmitting}>
                  Save as Draft
                </Button>
                <Button onClick={handleSchedulePost} disabled={isSubmitting || !date}>
                  {isSubmitting ? (
                    <>
                      <span className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-background border-t-foreground" />
                      Scheduling...
                    </>
                  ) : (
                    "Schedule Post"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="scheduled" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Scheduled Posts</CardTitle>
              <CardDescription>Manage your upcoming content</CardDescription>
            </CardHeader>
            <CardContent>
              <ScheduledPostsList posts={scheduledPosts} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="drafts" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Drafts</CardTitle>
              <CardDescription>Continue working on your saved content</CardDescription>
            </CardHeader>
            <CardContent>
              <DraftsList drafts={drafts} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardShell>
  )
}
