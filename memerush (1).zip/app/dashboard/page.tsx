"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { LineChart, PieChart } from "@/components/analytics/charts"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { RecentActivity } from "@/components/dashboard/recent-activity"
import { UpcomingPosts } from "@/components/dashboard/upcoming-posts"
import { TopPerformingContent } from "@/components/dashboard/top-performing-content"
import { AudienceOverview } from "@/components/dashboard/audience-overview"
import { checkAuth } from "@/lib/auth"
import { getAnalyticsData } from "@/lib/analytics"
import type { AnalyticsData } from "@/types/analytics"

export default function DashboardPage() {
  const router = useRouter()
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [timeRange, setTimeRange] = useState<"7d" | "30d" | "90d">("30d")

  useEffect(() => {
    const init = async () => {
      try {
        // Check if user is authenticated
        const isAuthenticated = await checkAuth()
        if (!isAuthenticated) {
          router.push("/login")
          return
        }

        // Fetch analytics data
        const data = await getAnalyticsData(timeRange)
        setAnalyticsData(data)
      } catch (error) {
        console.error("Failed to load dashboard data:", error)
      } finally {
        setLoading(false)
      }
    }

    init()
  }, [router, timeRange])

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (!analyticsData) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4 text-center">
        <h1 className="mb-4 text-2xl font-bold">Analytics Unavailable</h1>
        <p className="mb-8 text-muted-foreground">We couldn&apos;t load your analytics data. Please try again later.</p>
        <Button onClick={() => router.push("/feed")}>Back to Feed</Button>
      </div>
    )
  }

  return (
    <DashboardShell>
      <DashboardHeader heading="Analytics Dashboard" text="View your content performance and audience insights.">
        <div className="flex items-center gap-2">
          <Tabs defaultValue={timeRange} onValueChange={(value) => setTimeRange(value as "7d" | "30d" | "90d")}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="7d">7 Days</TabsTrigger>
              <TabsTrigger value="30d">30 Days</TabsTrigger>
              <TabsTrigger value="90d">90 Days</TabsTrigger>
            </TabsList>
          </Tabs>
          <Button onClick={() => router.push("/content/schedule")}>Schedule Post</Button>
        </div>
      </DashboardHeader>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.totalViews.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {analyticsData.viewsChange > 0 ? "+" : ""}
              {analyticsData.viewsChange}% from previous period
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Engagement Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.engagementRate}%</div>
            <p className="text-xs text-muted-foreground">
              {analyticsData.engagementChange > 0 ? "+" : ""}
              {analyticsData.engagementChange}% from previous period
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">New Followers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.newFollowers.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {analyticsData.followersChange > 0 ? "+" : ""}
              {analyticsData.followersChange}% from previous period
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.conversionRate}%</div>
            <p className="text-xs text-muted-foreground">
              {analyticsData.conversionChange > 0 ? "+" : ""}
              {analyticsData.conversionChange}% from previous period
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Performance Overview</CardTitle>
            <CardDescription>Your content performance over time</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <LineChart data={analyticsData.performanceData} />
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Audience Demographics</CardTitle>
            <CardDescription>Age and gender distribution</CardDescription>
          </CardHeader>
          <CardContent>
            <PieChart data={analyticsData.demographicsData} />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Top Performing Content</CardTitle>
            <CardDescription>Your best performing memes</CardDescription>
          </CardHeader>
          <CardContent>
            <TopPerformingContent data={analyticsData.topContent} />
          </CardContent>
        </Card>
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Audience Overview</CardTitle>
            <CardDescription>Where your audience comes from</CardDescription>
          </CardHeader>
          <CardContent>
            <AudienceOverview data={analyticsData.audienceData} />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Upcoming Scheduled Posts</CardTitle>
            <CardDescription>Your content calendar</CardDescription>
          </CardHeader>
          <CardContent>
            <UpcomingPosts posts={analyticsData.scheduledPosts} />
          </CardContent>
        </Card>
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest interactions with your content</CardDescription>
          </CardHeader>
          <CardContent>
            <RecentActivity activities={analyticsData.recentActivities} />
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
