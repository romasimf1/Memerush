"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { BottomNav } from "@/components/bottom-nav"
import { SettingsHeader } from "@/components/settings/settings-header"
import { ProfileSettings } from "@/components/settings/profile-settings"
import { AccountSettings } from "@/components/settings/account-settings"
import { AppearanceSettings } from "@/components/settings/appearance-settings"
import { NotificationSettings } from "@/components/settings/notification-settings"
import { PrivacySettings } from "@/components/settings/privacy-settings"
import { LanguageSettings } from "@/components/settings/language-settings"
import { checkAuth } from "@/lib/auth"
import { getUserSettings } from "@/lib/settings"
import type { UserSettings } from "@/types/settings"

export default function SettingsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [settings, setSettings] = useState<UserSettings | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const init = async () => {
      try {
        // Check if user is authenticated
        const isAuthenticated = await checkAuth()
        if (!isAuthenticated) {
          router.push("/login")
          return
        }

        // Fetch user settings
        const userSettings = await getUserSettings()
        setSettings(userSettings)
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load settings. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    init()
  }, [router, toast])

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (!settings) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4 text-center">
        <h1 className="mb-4 text-2xl font-bold">Settings Unavailable</h1>
        <p className="mb-8 text-muted-foreground">We couldn&apos;t load your settings. Please try again later.</p>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-background pb-16">
      <SettingsHeader />

      <div className="container max-w-4xl py-6">
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-6">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="privacy">Privacy</TabsTrigger>
            <TabsTrigger value="language">Language</TabsTrigger>
          </TabsList>

          <Card className="mt-6 border-none p-0 shadow-none">
            <TabsContent value="profile" className="mt-0">
              <ProfileSettings settings={settings} setSettings={setSettings} />
            </TabsContent>

            <TabsContent value="account" className="mt-0">
              <AccountSettings settings={settings} setSettings={setSettings} />
            </TabsContent>

            <TabsContent value="appearance" className="mt-0">
              <AppearanceSettings settings={settings} setSettings={setSettings} />
            </TabsContent>

            <TabsContent value="notifications" className="mt-0">
              <NotificationSettings settings={settings} setSettings={setSettings} />
            </TabsContent>

            <TabsContent value="privacy" className="mt-0">
              <PrivacySettings settings={settings} setSettings={setSettings} />
            </TabsContent>

            <TabsContent value="language" className="mt-0">
              <LanguageSettings settings={settings} setSettings={setSettings} />
            </TabsContent>
          </Card>
        </Tabs>
      </div>

      <BottomNav />
    </div>
  )
}
