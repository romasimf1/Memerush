"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Plus, ArrowRight, BarChart3, Users, Target, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { CampaignsList } from "@/components/campaigns/campaigns-list"
import { useToast } from "@/components/ui/use-toast"
import { checkAuth } from "@/lib/auth"
import { getCampaigns } from "@/lib/campaigns"
import type { Campaign } from "@/types/campaign"

export default function CampaignsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const init = async () => {
      try {
        // Check if user is authenticated
        const isAuthenticated = await checkAuth()
        if (!isAuthenticated) {
          router.push("/login")
          return
        }

        // Fetch campaigns
        const campaignsData = await getCampaigns()
        setCampaigns(campaignsData)
      } catch (error) {
        console.error("Failed to load campaigns:", error)
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load campaigns. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    init()
  }, [router, toast])

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  // Get active campaigns
  const activeCampaigns = campaigns.filter((campaign) => campaign.status === "active")

  // Get upcoming campaigns
  const upcomingCampaigns = campaigns.filter((campaign) => campaign.status === "scheduled")

  // Get completed campaigns
  const completedCampaigns = campaigns.filter((campaign) => campaign.status === "completed")

  return (
    <DashboardShell>
      <DashboardHeader heading="Campaign Manager" text="Create and manage your marketing campaigns.">
        <Button onClick={() => router.push("/campaigns/create")}>
          <Plus className="mr-2 h-4 w-4" /> New Campaign
        </Button>
      </DashboardHeader>

      {campaigns.length === 0 ? (
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>No Campaigns Yet</CardTitle>
            <CardDescription>Create your first marketing campaign to start promoting your content.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center py-8">
            <div className="mb-4 rounded-full bg-primary/10 p-6">
              <Target className="h-10 w-10 text-primary" />
            </div>
            <h3 className="mb-2 text-xl font-medium">Start Your First Campaign</h3>
            <p className="mb-6 max-w-md text-center text-muted-foreground">
              Campaigns help you organize your content around specific goals, track performance, and reach your target
              audience.
            </p>
            <Button onClick={() => router.push("/campaigns/create")}>
              Create Campaign <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Campaigns</CardTitle>
                <div className="rounded-full bg-primary/10 p-2">
                  <Calendar className="h-4 w-4 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{campaigns.length}</div>
                <p className="text-xs text-muted-foreground">
                  {activeCampaigns.length} active, {upcomingCampaigns.length} upcoming
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Reach</CardTitle>
                <div className="rounded-full bg-primary/10 p-2">
                  <Users className="h-4 w-4 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {campaigns.reduce((sum, campaign) => sum + campaign.reach, 0).toLocaleString()}
                </div>
                <p className="text-xs text-muted-foreground">Across all campaigns</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg. Engagement</CardTitle>
                <div className="rounded-full bg-primary/10 p-2">
                  <BarChart3 className="h-4 w-4 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {campaigns.length > 0
                    ? (
                        campaigns.reduce((sum, campaign) => sum + campaign.engagementRate, 0) / campaigns.length
                      ).toFixed(1)
                    : 0}
                  %
                </div>
                <p className="text-xs text-muted-foreground">Across all campaigns</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
                <div className="rounded-full bg-primary/10 p-2">
                  <Target className="h-4 w-4 text-primary" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {campaigns.length > 0
                    ? (
                        campaigns.reduce((sum, campaign) => sum + campaign.conversionRate, 0) / campaigns.length
                      ).toFixed(1)
                    : 0}
                  %
                </div>
                <p className="text-xs text-muted-foreground">Across all campaigns</p>
              </CardContent>
            </Card>
          </div>

          {activeCampaigns.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Active Campaigns</CardTitle>
                <CardDescription>Currently running marketing campaigns</CardDescription>
              </CardHeader>
              <CardContent>
                <CampaignsList campaigns={activeCampaigns} />
              </CardContent>
            </Card>
          )}

          {upcomingCampaigns.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Upcoming Campaigns</CardTitle>
                <CardDescription>Scheduled for future dates</CardDescription>
              </CardHeader>
              <CardContent>
                <CampaignsList campaigns={upcomingCampaigns} />
              </CardContent>
            </Card>
          )}

          {completedCampaigns.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Completed Campaigns</CardTitle>
                <CardDescription>Past campaigns and their results</CardDescription>
              </CardHeader>
              <CardContent>
                <CampaignsList campaigns={completedCampaigns} />
              </CardContent>
            </Card>
          )}
        </>
      )}
    </DashboardShell>
  )
}
