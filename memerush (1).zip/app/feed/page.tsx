"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { Heart, MessageCircle, Share2, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { MemeCard } from "@/components/meme-card"
import { BottomNav } from "@/components/bottom-nav"
import { CommentDialog } from "@/components/comment-dialog"
import { getMemes } from "@/lib/data"
import { checkAuth } from "@/lib/auth"
import type { Meme } from "@/types/meme"

export default function FeedPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [memes, setMemes] = useState<Meme[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isCommentsOpen, setIsCommentsOpen] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const init = async () => {
      try {
        // Check if user is authenticated
        const isAuthenticated = await checkAuth()
        if (!isAuthenticated) {
          router.push("/login")
          return
        }

        // Fetch memes
        const memesData = await getMemes()
        setMemes(memesData)
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load memes. Please try again.",
        })
      } finally {
        setLoading(false)
      }
    }

    init()
  }, [router, toast])

  const handleNext = () => {
    if (currentIndex < memes.length - 1) {
      setCurrentIndex(currentIndex + 1)
    }
  }

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1)
    }
  }

  const handleLike = (id: string) => {
    setMemes(
      memes.map((meme) =>
        meme.id === id ? { ...meme, liked: !meme.liked, likes: meme.liked ? meme.likes - 1 : meme.likes + 1 } : meme,
      ),
    )
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (memes.length === 0) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background p-4 text-center">
        <h1 className="mb-4 text-2xl font-bold">No memes found</h1>
        <p className="mb-8 text-muted-foreground">Be the first to upload a meme!</p>
        <Button onClick={() => router.push("/upload")}>Upload a Meme</Button>
        <BottomNav />
      </div>
    )
  }

  const currentMeme = memes[currentIndex]

  return (
    <div className="relative flex h-screen w-full flex-col overflow-hidden bg-background">
      <div
        className="absolute inset-0 flex-1 overflow-hidden"
        onClick={handleNext}
        onKeyDown={(e) => {
          if (e.key === "ArrowDown") handleNext()
          if (e.key === "ArrowUp") handlePrevious()
        }}
        tabIndex={0}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentMeme.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="h-full w-full"
          >
            <MemeCard meme={currentMeme} />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Interaction buttons */}
      <div className="absolute bottom-24 right-4 z-10 flex flex-col items-center gap-6">
        <Button
          variant="ghost"
          size="icon"
          className="group flex h-12 w-12 flex-col items-center justify-center rounded-full bg-background/20 backdrop-blur-lg"
          onClick={(e) => {
            e.stopPropagation()
            handleLike(currentMeme.id)
          }}
        >
          <Heart
            className={`h-6 w-6 transition-all ${currentMeme.liked ? "fill-red-500 text-red-500" : "text-white"}`}
          />
          <span className="mt-1 text-xs font-medium">{currentMeme.likes}</span>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="group flex h-12 w-12 flex-col items-center justify-center rounded-full bg-background/20 backdrop-blur-lg"
          onClick={(e) => {
            e.stopPropagation()
            setIsCommentsOpen(true)
          }}
        >
          <MessageCircle className="h-6 w-6 text-white" />
          <span className="mt-1 text-xs font-medium">{currentMeme.comments?.length || 0}</span>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="h-12 w-12 rounded-full bg-background/20 backdrop-blur-lg"
          onClick={(e) => {
            e.stopPropagation()
            router.push(`/profile/${currentMeme.username}`)
          }}
        >
          <User className="h-6 w-6 text-white" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="h-12 w-12 rounded-full bg-background/20 backdrop-blur-lg"
          onClick={(e) => {
            e.stopPropagation()
            // Share functionality would go here
            toast({
              title: "Share",
              description: "Sharing functionality coming soon!",
            })
          }}
        >
          <Share2 className="h-6 w-6 text-white" />
        </Button>
      </div>

      {/* Username display */}
      <div className="absolute bottom-20 left-4 z-10">
        <h2 className="text-lg font-bold text-white drop-shadow-md">@{currentMeme.username}</h2>
        {currentMeme.description && (
          <p className="mt-1 max-w-[250px] text-sm text-white/90 drop-shadow-md">{currentMeme.description}</p>
        )}
      </div>

      <BottomNav />

      <CommentDialog
        isOpen={isCommentsOpen}
        onClose={() => setIsCommentsOpen(false)}
        memeId={currentMeme.id}
        comments={currentMeme.comments || []}
      />
    </div>
  )
}
