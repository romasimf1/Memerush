"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { motion } from "framer-motion"
import { Upload, X, ImageIcon, Film } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { BottomNav } from "@/components/bottom-nav"
import { uploadMeme } from "@/lib/data"
import { checkAuth } from "@/lib/auth"

export default function UploadPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [description, setDescription] = useState("")
  const [isUploading, setIsUploading] = useState(false)
  const [isVideo, setIsVideo] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const checkAuthentication = async () => {
      const isAuthenticated = await checkAuth()
      if (!isAuthenticated) {
        router.push("/login")
      }
    }

    checkAuthentication()
  }, [router])

  useEffect(() => {
    if (!file) {
      setPreview(null)
      return
    }

    const objectUrl = URL.createObjectURL(file)
    setPreview(objectUrl)
    setIsVideo(file.type.startsWith("video/"))

    return () => URL.revokeObjectURL(objectUrl)
  }, [file])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      setFile(null)
      return
    }

    const selectedFile = e.target.files[0]
    const fileType = selectedFile.type

    // Check if file is an image or video
    if (!fileType.startsWith("image/") && !fileType.startsWith("video/")) {
      toast({
        variant: "destructive",
        title: "Invalid file type",
        description: "Please upload an image or video file.",
      })
      return
    }

    // Check file size (10MB limit)
    if (selectedFile.size > 10 * 1024 * 1024) {
      toast({
        variant: "destructive",
        title: "File too large",
        description: "Please upload a file smaller than 10MB.",
      })
      return
    }

    setFile(selectedFile)
  }

  const handleUpload = async () => {
    if (!file) {
      toast({
        variant: "destructive",
        title: "No file selected",
        description: "Please select an image or video to upload.",
      })
      return
    }

    setIsUploading(true)

    try {
      await uploadMeme(file, description)
      toast({
        title: "Upload successful",
        description: "Your meme has been uploaded!",
      })
      router.push("/feed")
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: "There was an error uploading your meme. Please try again.",
      })
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background pb-16">
      <div className="flex items-center justify-between border-b p-4">
        <h1 className="text-xl font-bold">Upload Meme</h1>
      </div>

      <div className="flex flex-1 flex-col p-4">
        <div
          className={`group relative mb-6 flex h-[300px] cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed ${
            preview ? "border-primary" : "border-muted-foreground/50"
          } bg-muted/30 transition-all hover:border-primary/70`}
          onClick={() => fileInputRef.current?.click()}
        >
          {preview ? (
            <>
              <div className="absolute inset-0 flex items-center justify-center">
                {isVideo ? (
                  <video
                    src={preview}
                    className="h-full w-full rounded-lg object-contain"
                    controls
                    autoPlay
                    muted
                    loop
                  />
                ) : (
                  <Image
                    src={preview || "/placeholder.svg"}
                    alt="Preview"
                    fill
                    className="rounded-lg object-contain p-2"
                    unoptimized
                  />
                )}
              </div>
              <div className="absolute right-2 top-2 z-10">
                <Button
                  variant="destructive"
                  size="icon"
                  className="h-8 w-8 rounded-full opacity-80"
                  onClick={(e) => {
                    e.stopPropagation()
                    setFile(null)
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </>
          ) : (
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="flex flex-col items-center justify-center space-y-4 p-6 text-center"
            >
              <div className="flex items-center gap-2 rounded-full bg-primary/20 p-4">
                <ImageIcon className="h-6 w-6 text-primary" />
                <Film className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground">Click to upload</p>
                <p className="text-sm text-muted-foreground">JPG, PNG, MP4, or WEBM (max 10MB)</p>
              </div>
            </motion.div>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,video/mp4,video/webm"
            className="hidden"
            onChange={handleFileChange}
          />
        </div>

        <div className="mb-6">
          <Textarea
            placeholder="Add a description (optional)"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="min-h-[100px] resize-none"
            maxLength={200}
          />
          <p className="mt-1 text-right text-xs text-muted-foreground">{description.length}/200</p>
        </div>

        <Button onClick={handleUpload} disabled={!file || isUploading} className="flex items-center gap-2" size="lg">
          {isUploading ? (
            <>
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
              Uploading...
            </>
          ) : (
            <>
              <Upload className="h-4 w-4" />
              Upload Meme
            </>
          )}
        </Button>
      </div>

      <BottomNav />
    </div>
  )
}
