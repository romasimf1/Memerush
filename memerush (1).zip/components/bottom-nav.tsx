"use client"

import { usePathname, useRouter } from "next/navigation"
import { Home, PlusSquare, User } from "lucide-react"
import { motion } from "framer-motion"

export function BottomNav() {
  const pathname = usePathname()
  const router = useRouter()

  const navItems = [
    {
      icon: Home,
      label: "Feed",
      path: "/feed",
    },
    {
      icon: PlusSquare,
      label: "Upload",
      path: "/upload",
    },
    {
      icon: User,
      label: "Profile",
      path: "/profile",
      // This will be replaced with the actual username in the isActive check
    },
  ]

  const isActive = (path: string) => {
    if (path === "/profile" && pathname.startsWith("/profile/")) {
      return true
    }
    return pathname === path
  }

  return (
    <div className="fixed bottom-0 left-0 z-50 w-full border-t bg-background/80 backdrop-blur-lg">
      <div className="mx-auto flex h-16 max-w-md items-center justify-around px-4">
        {navItems.map((item) => (
          <motion.button
            key={item.path}
            className="flex flex-col items-center justify-center"
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              if (item.path === "/profile") {
                // In a real app, you would get the current user's username from auth state
                router.push("/profile/currentuser")
              } else {
                router.push(item.path)
              }
            }}
          >
            <div
              className={`flex h-10 w-10 items-center justify-center rounded-full ${
                isActive(item.path) ? "bg-primary/10 text-primary" : "text-muted-foreground"
              }`}
            >
              <item.icon className="h-5 w-5" />
            </div>
            <span
              className={`mt-1 text-xs ${isActive(item.path) ? "font-medium text-primary" : "text-muted-foreground"}`}
            >
              {item.label}
            </span>
          </motion.button>
        ))}
      </div>
    </div>
  )
}
