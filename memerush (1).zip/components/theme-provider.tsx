"use client"

import type React from "react"
import { useState, useEffect, createContext, useContext } from "react"

type Theme = "light" | "dark" | "system"

interface ThemeContextProps {
  theme: Theme
  setTheme: (theme: Theme) => void
}

const ThemeContext = createContext<ThemeContextProps>({
  theme: "system",
  setTheme: () => {},
})

export function ThemeProvider({
  attribute,
  defaultTheme,
  enableSystem = false,
  children,
}: {
  attribute: string
  defaultTheme: Theme
  enableSystem?: boolean
  children: React.ReactNode
}) {
  const [theme, setThemeState] = useState<Theme>(() => {
    if (typeof window !== "undefined") {
      const storedTheme = localStorage.getItem("theme") as Theme | null
      if (storedTheme) {
        return storedTheme
      }
      if (enableSystem) {
        return getSystemTheme()
      }
    }
    return defaultTheme
  })

  useEffect(() => {
    if (typeof window === "undefined") {
      return
    }

    const handleChange = () => {
      if (!enableSystem) {
        return
      }
      setThemeState(getSystemTheme())
    }

    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", handleChange)

    return () => {
      window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change", handleChange)
    }
  }, [enableSystem])

  useEffect(() => {
    if (typeof window === "undefined") {
      return
    }

    localStorage.setItem("theme", theme)
    document.documentElement.setAttribute(attribute, theme)
  }, [theme, attribute])

  const setTheme = (theme: Theme) => {
    setThemeState(theme)
  }

  return <ThemeContext.Provider value={{ theme, setTheme }}>{children}</ThemeContext.Provider>
}

function getSystemTheme(): Theme {
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
}

export function useTheme() {
  return useContext(ThemeContext)
}
