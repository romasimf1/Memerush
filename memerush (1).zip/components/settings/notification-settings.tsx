"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { updateNotificationSettings } from "@/lib/settings"
import { useTranslation } from "@/lib/i18n"
import type { UserSettings } from "@/types/settings"

interface NotificationSettingsProps {
  settings: UserSettings
  setSettings: React.Dispatch<React.SetStateAction<UserSettings | null>>
}

export function NotificationSettings({ settings, setSettings }: NotificationSettingsProps) {
  const { t } = useTranslation()
  const { toast } = useToast()
  const [notificationSettings, setNotificationSettings] = useState({
    newFollowers: settings.notifications?.newFollowers ?? true,
    likes: settings.notifications?.likes ?? true,
    comments: settings.notifications?.comments ?? true,
    mentions: settings.notifications?.mentions ?? true,
    directMessages: settings.notifications?.directMessages ?? true,
    newContent: settings.notifications?.newContent ?? false,
    emailNotifications: settings.notifications?.emailNotifications ?? true,
    pushNotifications: settings.notifications?.pushNotifications ?? true,
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const updatedSettings = await updateNotificationSettings(notificationSettings)

      setSettings((prev) => (prev ? { ...prev, ...updatedSettings } : null))

      toast({
        title: t("notifications_updated"),
        description: t("notifications_update_success"),
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: t("update_failed"),
        description: t("notifications_update_error"),
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("notification_settings")}</CardTitle>
        <CardDescription>{t("notification_settings_desc")}</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">{t("notification_types")}</h3>

            <div className="flex items-center justify-between">
              <Label htmlFor="newFollowers" className="flex-1">
                {t("new_followers")}
              </Label>
              <Switch
                id="newFollowers"
                checked={notificationSettings.newFollowers}
                onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, newFollowers: checked }))}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="likes" className="flex-1">
                {t("likes")}
              </Label>
              <Switch
                id="likes"
                checked={notificationSettings.likes}
                onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, likes: checked }))}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="comments" className="flex-1">
                {t("comments")}
              </Label>
              <Switch
                id="comments"
                checked={notificationSettings.comments}
                onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, comments: checked }))}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="mentions" className="flex-1">
                {t("mentions")}
              </Label>
              <Switch
                id="mentions"
                checked={notificationSettings.mentions}
                onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, mentions: checked }))}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="directMessages" className="flex-1">
                {t("direct_messages")}
              </Label>
              <Switch
                id="directMessages"
                checked={notificationSettings.directMessages}
                onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, directMessages: checked }))}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="newContent" className="flex-1">
                {t("new_content_from_following")}
              </Label>
              <Switch
                id="newContent"
                checked={notificationSettings.newContent}
                onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, newContent: checked }))}
              />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">{t("delivery_methods")}</h3>

            <div className="flex items-center justify-between">
              <Label htmlFor="emailNotifications" className="flex-1">
                {t("email_notifications")}
              </Label>
              <Switch
                id="emailNotifications"
                checked={notificationSettings.emailNotifications}
                onCheckedChange={(checked) =>
                  setNotificationSettings((prev) => ({ ...prev, emailNotifications: checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="pushNotifications" className="flex-1">
                {t("push_notifications")}
              </Label>
              <Switch
                id="pushNotifications"
                checked={notificationSettings.pushNotifications}
                onCheckedChange={(checked) =>
                  setNotificationSettings((prev) => ({ ...prev, pushNotifications: checked }))
                }
              />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                {t("saving")}
              </>
            ) : (
              t("save_changes")
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
