"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Camera } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { updateProfile } from "@/lib/settings"
import { useTranslation } from "@/lib/i18n"
import type { UserSettings } from "@/types/settings"

interface ProfileSettingsProps {
  settings: UserSettings
  setSettings: React.Dispatch<React.SetStateAction<UserSettings | null>>
}

export function ProfileSettings({ settings, setSettings }: ProfileSettingsProps) {
  const { t } = useTranslation()
  const { toast } = useToast()
  const [displayName, setDisplayName] = useState(settings.displayName)
  const [bio, setBio] = useState(settings.bio || "")
  const [website, setWebsite] = useState(settings.website || "")
  const [location, setLocation] = useState(settings.location || "")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [avatar, setAvatar] = useState<File | null>(null)
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null)

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return

    const file = e.target.files[0]
    setAvatar(file)
    setAvatarPreview(URL.createObjectURL(file))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const updatedSettings = await updateProfile({
        displayName,
        bio,
        website,
        location,
        avatar,
      })

      setSettings((prev) => (prev ? { ...prev, ...updatedSettings } : null))

      toast({
        title: t("profile_updated"),
        description: t("profile_update_success"),
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: t("update_failed"),
        description: t("profile_update_error"),
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("profile_settings")}</CardTitle>
        <CardDescription>{t("profile_settings_desc")}</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center space-y-4">
            <div className="relative">
              <div className="relative h-24 w-24 overflow-hidden rounded-full">
                <Image
                  src={avatarPreview || settings.avatar || "/placeholder.svg?height=96&width=96"}
                  alt="Profile"
                  fill
                  className="object-cover"
                  unoptimized
                />
              </div>
              <label
                htmlFor="avatar-upload"
                className="absolute bottom-0 right-0 flex h-8 w-8 cursor-pointer items-center justify-center rounded-full bg-primary text-primary-foreground"
              >
                <Camera className="h-4 w-4" />
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarChange}
                />
              </label>
            </div>
            <p className="text-sm text-muted-foreground">{t("avatar_requirements")}</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="displayName">{t("display_name")}</Label>
            <Input
              id="displayName"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder={t("display_name_placeholder")}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">{t("bio")}</Label>
            <Textarea
              id="bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder={t("bio_placeholder")}
              className="min-h-[100px] resize-none"
              maxLength={160}
            />
            <p className="text-xs text-muted-foreground text-right">{bio.length}/160</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="website">{t("website")}</Label>
            <Input
              id="website"
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
              placeholder={t("website_placeholder")}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">{t("location")}</Label>
            <Input
              id="location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder={t("location_placeholder")}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                {t("saving")}
              </>
            ) : (
              t("save_changes")
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
