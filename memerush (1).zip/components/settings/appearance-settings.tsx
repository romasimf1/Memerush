"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useToast } from "@/components/ui/use-toast"
import { updateAppearance } from "@/lib/settings"
import { useTranslation } from "@/lib/i18n"
import { useTheme } from "@/components/theme-provider"
import type { UserSettings } from "@/types/settings"

interface AppearanceSettingsProps {
  settings: UserSettings
  setSettings: React.Dispatch<React.SetStateAction<UserSettings | null>>
}

export function AppearanceSettings({ settings, setSettings }: AppearanceSettingsProps) {
  const { t } = useTranslation()
  const { toast } = useToast()
  const { setTheme } = useTheme()
  const [theme, setThemeState] = useState(settings.theme)
  const [accentColor, setAccentColor] = useState(settings.accentColor || "purple")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const updatedSettings = await updateAppearance({
        theme,
        accentColor,
      })

      setSettings((prev) => (prev ? { ...prev, ...updatedSettings } : null))

      // Update theme in real-time
      setTheme(theme)

      toast({
        title: t("appearance_updated"),
        description: t("appearance_update_success"),
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: t("update_failed"),
        description: t("appearance_update_error"),
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("appearance_settings")}</CardTitle>
        <CardDescription>{t("appearance_settings_desc")}</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label>{t("theme")}</Label>
            <RadioGroup
              value={theme}
              onValueChange={(value) => {
                setThemeState(value as "light" | "dark" | "system")
                // Preview theme change immediately
                setTheme(value as "light" | "dark" | "system")
              }}
              className="grid grid-cols-3 gap-4"
            >
              <div>
                <RadioGroupItem value="light" id="light" className="peer sr-only" />
                <Label
                  htmlFor="light"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                >
                  <div className="mb-3 h-16 w-16 rounded-md bg-[#FFFFFF] border"></div>
                  {t("light")}
                </Label>
              </div>
              <div>
                <RadioGroupItem value="dark" id="dark" className="peer sr-only" />
                <Label
                  htmlFor="dark"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                >
                  <div className="mb-3 h-16 w-16 rounded-md bg-[#0F0F0F] border"></div>
                  {t("dark")}
                </Label>
              </div>
              <div>
                <RadioGroupItem value="system" id="system" className="peer sr-only" />
                <Label
                  htmlFor="system"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                >
                  <div className="mb-3 h-16 w-16 rounded-md bg-gradient-to-r from-[#FFFFFF] to-[#0F0F0F] border"></div>
                  {t("system")}
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-4">
            <Label>{t("accent_color")}</Label>
            <RadioGroup
              value={accentColor}
              onValueChange={setAccentColor}
              className="grid grid-cols-3 gap-4 sm:grid-cols-5"
            >
              <div>
                <RadioGroupItem value="purple" id="purple" className="peer sr-only" />
                <Label
                  htmlFor="purple"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                >
                  <div className="mb-2 h-8 w-8 rounded-full bg-purple-500"></div>
                  {t("purple")}
                </Label>
              </div>
              <div>
                <RadioGroupItem value="blue" id="blue" className="peer sr-only" />
                <Label
                  htmlFor="blue"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                >
                  <div className="mb-2 h-8 w-8 rounded-full bg-blue-500"></div>
                  {t("blue")}
                </Label>
              </div>
              <div>
                <RadioGroupItem value="green" id="green" className="peer sr-only" />
                <Label
                  htmlFor="green"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                >
                  <div className="mb-2 h-8 w-8 rounded-full bg-green-500"></div>
                  {t("green")}
                </Label>
              </div>
              <div>
                <RadioGroupItem value="red" id="red" className="peer sr-only" />
                <Label
                  htmlFor="red"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                >
                  <div className="mb-2 h-8 w-8 rounded-full bg-red-500"></div>
                  {t("red")}
                </Label>
              </div>
              <div>
                <RadioGroupItem value="orange" id="orange" className="peer sr-only" />
                <Label
                  htmlFor="orange"
                  className="flex flex-col items-center justify-between rounded-md border-2 border-muted p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                >
                  <div className="mb-2 h-8 w-8 rounded-full bg-orange-500"></div>
                  {t("orange")}
                </Label>
              </div>
            </RadioGroup>
          </div>
        </CardContent>
        <CardFooter>
          <Button
            type="submit"
            disabled={isSubmitting || (theme === settings.theme && accentColor === settings.accentColor)}
          >
            {isSubmitting ? (
              <>
                <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                {t("saving")}
              </>
            ) : (
              t("save_changes")
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
