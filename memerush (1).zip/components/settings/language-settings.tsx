"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useToast } from "@/components/ui/use-toast"
import { updateLanguageSettings } from "@/lib/settings"
import { useTranslation } from "@/lib/i18n"
import type { UserSettings } from "@/types/settings"

interface LanguageSettingsProps {
  settings: UserSettings
  setSettings: React.Dispatch<React.SetStateAction<UserSettings | null>>
}

export function LanguageSettings({ settings, setSettings }: LanguageSettingsProps) {
  const { t, changeLanguage } = useTranslation()
  const { toast } = useToast()
  const [language, setLanguage] = useState(settings.language || "en")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const updatedSettings = await updateLanguageSettings({
        language,
      })

      setSettings((prev) => (prev ? { ...prev, ...updatedSettings } : null))

      // Change language in real-time
      changeLanguage(language)

      toast({
        title: t("language_updated"),
        description: t("language_update_success"),
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: t("update_failed"),
        description: t("language_update_error"),
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("language_settings")}</CardTitle>
        <CardDescription>{t("language_settings_desc")}</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label>{t("app_language")}</Label>
            <RadioGroup
              value={language}
              onValueChange={(value) => {
                setLanguage(value)
                // Preview language change immediately
                changeLanguage(value)
              }}
              className="grid gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="en" id="english" />
                <Label htmlFor="english">English</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="ru" id="russian" />
                <Label htmlFor="russian">Русский</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="es" id="spanish" />
                <Label htmlFor="spanish">Español</Label>
              </div>
            </RadioGroup>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isSubmitting || language === settings.language}>
            {isSubmitting ? (
              <>
                <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                {t("saving")}
              </>
            ) : (
              t("save_changes")
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
