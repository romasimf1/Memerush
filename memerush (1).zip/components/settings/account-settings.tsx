"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertTriangle } from "lucide-react"
import { updateUsername, updateEmail, updatePassword, deleteAccount } from "@/lib/settings"
import { useTranslation } from "@/lib/i18n"
import { useRouter } from "next/navigation"
import type { UserSettings } from "@/types/settings"

interface AccountSettingsProps {
  settings: UserSettings
  setSettings: React.Dispatch<React.SetStateAction<UserSettings | null>>
}

export function AccountSettings({ settings, setSettings }: AccountSettingsProps) {
  const { t } = useTranslation()
  const { toast } = useToast()
  const router = useRouter()

  // Username state
  const [username, setUsername] = useState(settings.username)
  const [isUsernameSubmitting, setIsUsernameSubmitting] = useState(false)

  // Email state
  const [email, setEmail] = useState(settings.email)
  const [isEmailSubmitting, setIsEmailSubmitting] = useState(false)

  // Password state
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [isPasswordSubmitting, setIsPasswordSubmitting] = useState(false)

  // Delete account state
  const [deleteConfirmation, setDeleteConfirmation] = useState("")
  const [isDeleteSubmitting, setIsDeleteSubmitting] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)

  const handleUsernameSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsUsernameSubmitting(true)

    try {
      const updatedSettings = await updateUsername(username)
      setSettings((prev) => (prev ? { ...prev, ...updatedSettings } : null))

      toast({
        title: t("username_updated"),
        description: t("username_update_success"),
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: t("update_failed"),
        description: t("username_update_error"),
      })
    } finally {
      setIsUsernameSubmitting(false)
    }
  }

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsEmailSubmitting(true)

    try {
      const updatedSettings = await updateEmail(email)
      setSettings((prev) => (prev ? { ...prev, ...updatedSettings } : null))

      toast({
        title: t("email_updated"),
        description: t("email_update_success"),
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: t("update_failed"),
        description: t("email_update_error"),
      })
    } finally {
      setIsEmailSubmitting(false)
    }
  }

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (newPassword !== confirmPassword) {
      toast({
        variant: "destructive",
        title: t("password_mismatch"),
        description: t("password_mismatch_desc"),
      })
      return
    }

    setIsPasswordSubmitting(true)

    try {
      await updatePassword(currentPassword, newPassword)

      // Reset form
      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")

      toast({
        title: t("password_updated"),
        description: t("password_update_success"),
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: t("update_failed"),
        description: t("password_update_error"),
      })
    } finally {
      setIsPasswordSubmitting(false)
    }
  }

  const handleDeleteAccount = async () => {
    if (deleteConfirmation !== settings.username) {
      toast({
        variant: "destructive",
        title: t("confirmation_error"),
        description: t("username_confirmation_error"),
      })
      return
    }

    setIsDeleteSubmitting(true)

    try {
      await deleteAccount()

      toast({
        title: t("account_deleted"),
        description: t("account_deleted_desc"),
      })

      // Redirect to login page
      router.push("/login")
    } catch (error) {
      toast({
        variant: "destructive",
        title: t("delete_failed"),
        description: t("account_delete_error"),
      })
      setIsDeleteSubmitting(false)
      setIsDeleteDialogOpen(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{t("username")}</CardTitle>
          <CardDescription>{t("username_desc")}</CardDescription>
        </CardHeader>
        <form onSubmit={handleUsernameSubmit}>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="username">{t("username")}</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t("username_placeholder")}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={isUsernameSubmitting || username === settings.username}>
              {isUsernameSubmitting ? (
                <>
                  <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                  {t("saving")}
                </>
              ) : (
                t("update_username")
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("email")}</CardTitle>
          <CardDescription>{t("email_desc")}</CardDescription>
        </CardHeader>
        <form onSubmit={handleEmailSubmit}>
          <CardContent>
            <div className="space-y-2">
              <Label htmlFor="email">{t("email")}</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t("email_placeholder")}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={isEmailSubmitting || email === settings.email}>
              {isEmailSubmitting ? (
                <>
                  <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                  {t("saving")}
                </>
              ) : (
                t("update_email")
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("password")}</CardTitle>
          <CardDescription>{t("password_desc")}</CardDescription>
        </CardHeader>
        <form onSubmit={handlePasswordSubmit}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="currentPassword">{t("current_password")}</Label>
              <Input
                id="currentPassword"
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="newPassword">{t("new_password")}</Label>
              <Input
                id="newPassword"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">{t("confirm_password")}</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button
              type="submit"
              disabled={isPasswordSubmitting || !currentPassword || !newPassword || !confirmPassword}
            >
              {isPasswordSubmitting ? (
                <>
                  <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                  {t("saving")}
                </>
              ) : (
                t("update_password")
              )}
            </Button>
          </CardFooter>
        </form>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{t("danger_zone")}</CardTitle>
          <CardDescription>{t("danger_zone_desc")}</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>{t("delete_account")}</AlertTitle>
            <AlertDescription>{t("delete_account_warning")}</AlertDescription>
          </Alert>
        </CardContent>
        <CardFooter>
          <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive">{t("delete_account")}</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t("delete_account_confirmation")}</DialogTitle>
                <DialogDescription>{t("delete_account_confirmation_desc")}</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <p className="text-sm text-muted-foreground">
                  {t("delete_account_type_username", { username: settings.username })}
                </p>
                <Input
                  value={deleteConfirmation}
                  onChange={(e) => setDeleteConfirmation(e.target.value)}
                  placeholder={settings.username}
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                  {t("cancel")}
                </Button>
                <Button variant="destructive" onClick={handleDeleteAccount} disabled={isDeleteSubmitting}>
                  {isDeleteSubmitting ? (
                    <>
                      <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                      {t("deleting")}
                    </>
                  ) : (
                    t("confirm_delete")
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardFooter>
      </Card>
    </div>
  )
}
