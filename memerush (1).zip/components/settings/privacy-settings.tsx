"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useToast } from "@/components/ui/use-toast"
import { updatePrivacySettings } from "@/lib/settings"
import { useTranslation } from "@/lib/i18n"
import type { UserSettings } from "@/types/settings"

interface PrivacySettingsProps {
  settings: UserSettings
  setSettings: React.Dispatch<React.SetStateAction<UserSettings | null>>
}

export function PrivacySettings({ settings, setSettings }: PrivacySettingsProps) {
  const { t } = useTranslation()
  const { toast } = useToast()
  const [privacySettings, setPrivacySettings] = useState({
    privateAccount: settings.privacy?.privateAccount ?? false,
    showActivity: settings.privacy?.showActivity ?? true,
    allowTagging: settings.privacy?.allowTagging ?? "everyone", // "everyone", "following", "none"
    allowComments: settings.privacy?.allowComments ?? "everyone", // "everyone", "following", "none"
    allowDirectMessages: settings.privacy?.allowDirectMessages ?? "everyone", // "everyone", "following", "none"
    dataPersonalization: settings.privacy?.dataPersonalization ?? true,
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const updatedSettings = await updatePrivacySettings(privacySettings)

      setSettings((prev) => (prev ? { ...prev, ...updatedSettings } : null))

      toast({
        title: t("privacy_updated"),
        description: t("privacy_update_success"),
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: t("update_failed"),
        description: t("privacy_update_error"),
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("privacy_settings")}</CardTitle>
        <CardDescription>{t("privacy_settings_desc")}</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">{t("account_privacy")}</h3>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="privateAccount">{t("private_account")}</Label>
                <p className="text-sm text-muted-foreground">{t("private_account_desc")}</p>
              </div>
              <Switch
                id="privateAccount"
                checked={privacySettings.privateAccount}
                onCheckedChange={(checked) => setPrivacySettings((prev) => ({ ...prev, privateAccount: checked }))}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="showActivity">{t("show_activity")}</Label>
                <p className="text-sm text-muted-foreground">{t("show_activity_desc")}</p>
              </div>
              <Switch
                id="showActivity"
                checked={privacySettings.showActivity}
                onCheckedChange={(checked) => setPrivacySettings((prev) => ({ ...prev, showActivity: checked }))}
              />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">{t("interactions")}</h3>

            <div className="space-y-2">
              <Label>{t("allow_tagging")}</Label>
              <RadioGroup
                value={privacySettings.allowTagging}
                onValueChange={(value) => setPrivacySettings((prev) => ({ ...prev, allowTagging: value }))}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="everyone" id="tagging-everyone" />
                  <Label htmlFor="tagging-everyone">{t("everyone")}</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="following" id="tagging-following" />
                  <Label htmlFor="tagging-following">{t("people_i_follow")}</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="none" id="tagging-none" />
                  <Label htmlFor="tagging-none">{t("no_one")}</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label>{t("allow_comments")}</Label>
              <RadioGroup
                value={privacySettings.allowComments}
                onValueChange={(value) => setPrivacySettings((prev) => ({ ...prev, allowComments: value }))}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="everyone" id="comments-everyone" />
                  <Label htmlFor="comments-everyone">{t("everyone")}</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="following" id="comments-following" />
                  <Label htmlFor="comments-following">{t("people_i_follow")}</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="none" id="comments-none" />
                  <Label htmlFor="comments-none">{t("no_one")}</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label>{t("allow_direct_messages")}</Label>
              <RadioGroup
                value={privacySettings.allowDirectMessages}
                onValueChange={(value) => setPrivacySettings((prev) => ({ ...prev, allowDirectMessages: value }))}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="everyone" id="dm-everyone" />
                  <Label htmlFor="dm-everyone">{t("everyone")}</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="following" id="dm-following" />
                  <Label htmlFor="dm-following">{t("people_i_follow")}</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="none" id="dm-none" />
                  <Label htmlFor="dm-none">{t("no_one")}</Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">{t("data_and_personalization")}</h3>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="dataPersonalization">{t("data_personalization")}</Label>
                <p className="text-sm text-muted-foreground">{t("data_personalization_desc")}</p>
              </div>
              <Switch
                id="dataPersonalization"
                checked={privacySettings.dataPersonalization}
                onCheckedChange={(checked) => setPrivacySettings((prev) => ({ ...prev, dataPersonalization: checked }))}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? (
              <>
                <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-background border-t-foreground" />
                {t("saving")}
              </>
            ) : (
              t("save_changes")
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
