"use client"

import { usePathname, useRouter } from "next/navigation"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function FeedTabs() {
  const pathname = usePathname()
  const router = useRouter()

  const isForYou = pathname === "/feed"
  const isFollowing = pathname === "/feed/following"

  const handleTabChange = (value: string) => {
    if (value === "for-you") {
      router.push("/feed")
    } else if (value === "following") {
      router.push("/feed/following")
    }
  }

  return (
    <div className="fixed top-0 z-20 w-full bg-background/80 p-2 backdrop-blur-md">
      <Tabs defaultValue={isFollowing ? "following" : "for-you"} className="w-full" onValueChange={handleTabChange}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="for-you">For You</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  )
}
