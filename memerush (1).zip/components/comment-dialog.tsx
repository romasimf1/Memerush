"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import type { Comment } from "@/types/comment"

interface CommentDialogProps {
  isOpen: boolean
  onClose: () => void
  memeId: string
  comments: Comment[]
}

export function CommentDialog({ isOpen, onClose, memeId, comments }: CommentDialogProps) {
  const [newComment, setNewComment] = useState("")
  const [localComments, setLocalComments] = useState<Comment[]>(comments)

  const handleAddComment = () => {
    if (!newComment.trim()) return

    const comment: Comment = {
      id: `comment-${Date.now()}`,
      username: "currentuser", // In a real app, get from auth state
      text: newComment,
      timestamp: new Date().toISOString(),
    }

    setLocalComments([comment, ...localComments])
    setNewComment("")
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-4 backdrop-blur-sm sm:items-center"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            className="w-full max-w-md rounded-t-xl bg-background sm:rounded-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b p-4">
              <h2 className="text-lg font-semibold">Comments</h2>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="max-h-[60vh] overflow-y-auto p-4">
              {localComments.length > 0 ? (
                <div className="space-y-4">
                  {localComments.map((comment) => (
                    <div key={comment.id} className="flex gap-3">
                      <div className="h-8 w-8 flex-shrink-0 rounded-full bg-muted" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">@{comment.username}</p>
                          <span className="text-xs text-muted-foreground">
                            {new Date(comment.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="mt-1 text-sm">{comment.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <p className="text-lg font-medium">No comments yet</p>
                  <p className="text-sm text-muted-foreground">Be the first to comment!</p>
                </div>
              )}
            </div>

            <div className="border-t p-4">
              <form
                className="flex gap-2"
                onSubmit={(e) => {
                  e.preventDefault()
                  handleAddComment()
                }}
              >
                <Input
                  placeholder="Add a comment..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit" size="icon" disabled={!newComment.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
