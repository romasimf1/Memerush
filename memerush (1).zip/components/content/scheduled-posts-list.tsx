"use client"

import { useState } from "react"
import Image from "next/image"
import { format } from "date-fns"
import { Edit, Trash2, MoreHorizontal, Play, Pause, Instagram, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import type { ScheduledPost } from "@/types/content"

interface ScheduledPostsListProps {
  posts: ScheduledPost[]
}

export function ScheduledPostsList({ posts }: ScheduledPostsListProps) {
  const { toast } = useToast()
  const [localPosts, setLocalPosts] = useState<ScheduledPost[]>(posts)

  const handleDeletePost = (id: string) => {
    // In a real app, this would call an API
    setLocalPosts(localPosts.filter((post) => post.id !== id))
    toast({
      title: "Post deleted",
      description: "The scheduled post has been deleted.",
    })
  }

  const handlePausePost = (id: string) => {
    setLocalPosts(
      localPosts.map((post) =>
        post.id === id ? { ...post, status: post.status === "paused" ? "scheduled" : "paused" } : post,
      ),
    )

    const post = localPosts.find((p) => p.id === id)
    toast({
      title: post?.status === "paused" ? "Post resumed" : "Post paused",
      description:
        post?.status === "paused" ? "The scheduled post has been resumed." : "The scheduled post has been paused.",
    })
  }

  if (localPosts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <p className="text-lg font-medium">No scheduled posts</p>
        <p className="text-sm text-muted-foreground">You don&apos;t have any posts scheduled yet.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {localPosts.map((post) => (
        <div key={post.id} className="flex items-start gap-4 rounded-lg border p-4">
          <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-md">
            {post.mediaType === "video" ? (
              <video src={post.mediaSrc} className="h-full w-full object-cover" muted />
            ) : (
              <Image src={post.mediaSrc || "/placeholder.svg"} alt="" fill className="object-cover" unoptimized />
            )}
          </div>

          <div className="flex-1 space-y-1">
            <div className="flex items-center gap-2">
              <p className="font-medium">{format(new Date(post.scheduledFor), "PPP 'at' p")}</p>
              <Badge variant={post.status === "paused" ? "outline" : "default"}>
                {post.status === "paused" ? "Paused" : "Scheduled"}
              </Badge>
            </div>

            <p className="line-clamp-2 text-sm text-muted-foreground">{post.description}</p>

            <div className="flex flex-wrap gap-1">
              {post.platforms.map((platform) => (
                <div key={platform} className="flex items-center text-xs text-muted-foreground">
                  {platform === "instagram" && <Instagram className="mr-1 h-3 w-3" />}
                  {platform === "twitter" && <Twitter className="mr-1 h-3 w-3" />}
                  {platform === "memerush" && <span className="mr-1">🚀</span>}
                  {platform}
                </div>
              ))}
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handlePausePost(post.id)}>
                {post.status === "paused" ? (
                  <>
                    <Play className="mr-2 h-4 w-4" /> Resume
                  </>
                ) : (
                  <>
                    <Pause className="mr-2 h-4 w-4" /> Pause
                  </>
                )}
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Edit className="mr-2 h-4 w-4" /> Edit
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="text-destructive focus:text-destructive"
                onClick={() => handleDeletePost(post.id)}
              >
                <Trash2 className="mr-2 h-4 w-4" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ))}
    </div>
  )
}
