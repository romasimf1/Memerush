"use client"

import type React from "react"

import { useRef, useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { ImageIcon, Film, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"

interface MediaUploaderProps {
  file: File | null
  onFileChange: (file: File | null) => void
  accept?: string
  maxSize?: number
}

export function MediaUploader({
  file,
  onFileChange,
  accept = "image/*",
  maxSize = 5 * 1024 * 1024, // 5MB default
}: MediaUploaderProps) {
  const { toast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [preview, setPreview] = useState<string | null>(null)
  const [isVideo, setIsVideo] = useState(false)

  // Update preview when file changes
  const updatePreview = (file: File | null) => {
    if (!file) {
      setPreview(null)
      return
    }

    const objectUrl = URL.createObjectURL(file)
    setPreview(objectUrl)
    setIsVideo(file.type.startsWith("video/"))

    return () => URL.revokeObjectURL(objectUrl)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) {
      onFileChange(null)
      setPreview(null)
      return
    }

    const selectedFile = e.target.files[0]

    // Check file size
    if (selectedFile.size > maxSize) {
      toast({
        variant: "destructive",
        title: "File too large",
        description: `Please upload a file smaller than ${Math.round(maxSize / (1024 * 1024))}MB.`,
      })
      return
    }

    onFileChange(selectedFile)
    updatePreview(selectedFile)
  }

  return (
    <div
      className={`group relative flex h-[200px] cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed ${
        preview ? "border-primary" : "border-muted-foreground/50"
      } bg-muted/30 transition-all hover:border-primary/70`}
      onClick={() => fileInputRef.current?.click()}
    >
      {preview ? (
        <>
          <div className="absolute inset-0 flex items-center justify-center">
            {isVideo ? (
              <video src={preview} className="h-full w-full rounded-lg object-contain" controls autoPlay muted loop />
            ) : (
              <Image
                src={preview || "/placeholder.svg"}
                alt="Preview"
                fill
                className="rounded-lg object-contain p-2"
                unoptimized
              />
            )}
          </div>
          <div className="absolute right-2 top-2 z-10">
            <Button
              variant="destructive"
              size="icon"
              className="h-8 w-8 rounded-full opacity-80"
              onClick={(e) => {
                e.stopPropagation()
                onFileChange(null)
                setPreview(null)
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </>
      ) : (
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="flex flex-col items-center justify-center space-y-4 p-6 text-center"
        >
          <div className="flex items-center gap-2 rounded-full bg-primary/20 p-4">
            <ImageIcon className="h-6 w-6 text-primary" />
            <Film className="h-6 w-6 text-primary" />
          </div>
          <div>
            <p className="font-medium text-foreground">Click to upload</p>
            <p className="text-sm text-muted-foreground">
              {accept.includes("video") ? "JPG, PNG, MP4, or WEBM" : "JPG or PNG"}
              {maxSize && ` (max ${Math.round(maxSize / (1024 * 1024))}MB)`}
            </p>
          </div>
        </motion.div>
      )}
      <input ref={fileInputRef} type="file" accept={accept} className="hidden" onChange={handleFileChange} />
    </div>
  )
}
