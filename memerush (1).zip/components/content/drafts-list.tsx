"use client"

import { useState } from "react"
import Image from "next/image"
import { format } from "date-fns"
import { Edit, Trash2, MoreHorizontal, Calendar, Instagram, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from "@/components/ui/use-toast"
import type { Draft } from "@/types/content"

interface DraftsListProps {
  drafts: Draft[]
}

export function DraftsList({ drafts }: DraftsListProps) {
  const { toast } = useToast()
  const [localDrafts, setLocalDrafts] = useState<Draft[]>(drafts)

  const handleDeleteDraft = (id: string) => {
    // In a real app, this would call an API
    setLocalDrafts(localDrafts.filter((draft) => draft.id !== id))
    toast({
      title: "Draft deleted",
      description: "The draft has been deleted.",
    })
  }

  if (localDrafts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <p className="text-lg font-medium">No drafts</p>
        <p className="text-sm text-muted-foreground">You don&apos;t have any saved drafts yet.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {localDrafts.map((draft) => (
        <div key={draft.id} className="flex items-start gap-4 rounded-lg border p-4">
          <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-md">
            {draft.mediaType === "video" ? (
              <video src={draft.mediaSrc} className="h-full w-full object-cover" muted />
            ) : (
              <Image src={draft.mediaSrc || "/placeholder.svg"} alt="" fill className="object-cover" unoptimized />
            )}
          </div>

          <div className="flex-1 space-y-1">
            <div className="flex items-center gap-2">
              <p className="font-medium">Draft</p>
              <span className="text-xs text-muted-foreground">
                Last edited: {format(new Date(draft.updatedAt), "PPP")}
              </span>
            </div>

            <p className="line-clamp-2 text-sm text-muted-foreground">{draft.description || "No description"}</p>

            <div className="flex flex-wrap gap-1">
              {draft.platforms.map((platform) => (
                <div key={platform} className="flex items-center text-xs text-muted-foreground">
                  {platform === "instagram" && <Instagram className="mr-1 h-3 w-3" />}
                  {platform === "twitter" && <Twitter className="mr-1 h-3 w-3" />}
                  {platform === "memerush" && <span className="mr-1">🚀</span>}
                  {platform}
                </div>
              ))}
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Edit className="mr-2 h-4 w-4" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Calendar className="mr-2 h-4 w-4" /> Schedule
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="text-destructive focus:text-destructive"
                onClick={() => handleDeleteDraft(draft.id)}
              >
                <Trash2 className="mr-2 h-4 w-4" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      ))}
    </div>
  )
}
