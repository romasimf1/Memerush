"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import type { Meme } from "@/types/meme"

interface MemeCardProps {
  meme: Meme
}

export function MemeCard({ meme }: MemeCardProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isVideoPlaying, setIsVideoPlaying] = useState(false)

  useEffect(() => {
    const videoElement = videoRef.current
    if (videoElement && meme.type === "video") {
      videoElement.play().catch((error) => {
        console.error("Error playing video:", error)
      })
      setIsVideoPlaying(true)
    }

    return () => {
      if (videoElement) {
        videoElement.pause()
      }
    }
  }, [meme])

  const toggleVideoPlayback = () => {
    if (!videoRef.current) return

    if (isVideoPlaying) {
      videoRef.current.pause()
    } else {
      videoRef.current.play().catch((error) => {
        console.error("Error playing video:", error)
      })
    }

    setIsVideoPlaying(!isVideoPlaying)
  }

  return (
    <div className="relative h-full w-full">
      {meme.type === "video" ? (
        <video
          ref={videoRef}
          src={meme.src}
          className="h-full w-full object-contain"
          loop
          playsInline
          muted
          autoPlay
          onClick={(e) => {
            e.stopPropagation()
            toggleVideoPlayback()
          }}
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-black">
          <Image
            src={meme.src || "/placeholder.svg"}
            alt={meme.description || "Meme"}
            fill
            className="object-contain"
            unoptimized
          />
        </div>
      )}
    </div>
  )
}
