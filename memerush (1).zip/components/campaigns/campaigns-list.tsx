"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { format } from "date-fns"
import { Edit, Trash2, MoreHorizontal, BarChart3, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import type { Campaign } from "@/types/campaign"

interface CampaignsListProps {
  campaigns: Campaign[]
}

export function CampaignsList({ campaigns }: CampaignsListProps) {
  const router = useRouter()
  const { toast } = useToast()
  const [localCampaigns, setLocalCampaigns] = useState<Campaign[]>(campaigns)

  const handleDeleteCampaign = (id: string) => {
    // In a real app, this would call an API
    setLocalCampaigns(localCampaigns.filter((campaign) => campaign.id !== id))
    toast({
      title: "Campaign deleted",
      description: "The campaign has been deleted.",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500"
      case "scheduled":
        return "bg-blue-500"
      case "completed":
        return "bg-gray-500"
      case "paused":
        return "bg-yellow-500"
      default:
        return "bg-gray-500"
    }
  }

  if (localCampaigns.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <p className="text-lg font-medium">No campaigns</p>
        <p className="text-sm text-muted-foreground">You don&apos;t have any campaigns in this category.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {localCampaigns.map((campaign) => (
        <div key={campaign.id} className="rounded-lg border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`h-3 w-3 rounded-full ${getStatusColor(campaign.status)}`} />
              <h3 className="font-medium">{campaign.name}</h3>
              <Badge variant="outline">{campaign.status}</Badge>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => router.push(`/campaigns/${campaign.id}`)}>
                  <ExternalLink className="mr-2 h-4 w-4" /> View Details
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => router.push(`/campaigns/${campaign.id}/analytics`)}>
                  <BarChart3 className="mr-2 h-4 w-4" /> Analytics
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Edit className="mr-2 h-4 w-4" /> Edit
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={() => handleDeleteCampaign(campaign.id)}
                >
                  <Trash2 className="mr-2 h-4 w-4" /> Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="mt-2 grid gap-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Goal:</span>
              <span>{campaign.goal}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-muted-foreground">Timeline:</span>
              <span>
                {format(new Date(campaign.startDate), "MMM d")} - {format(new Date(campaign.endDate), "MMM d, yyyy")}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-muted-foreground">Budget:</span>
              <span>${campaign.budget.toLocaleString()}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-muted-foreground">Performance:</span>
              <span>{campaign.performance}</span>
            </div>
          </div>

          {campaign.status === "active" && (
            <div className="mt-4">
              <div className="flex justify-between text-xs">
                <span>Progress</span>
                <span>{campaign.progress}%</span>
              </div>
              <Progress value={campaign.progress} className="mt-1" />
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
