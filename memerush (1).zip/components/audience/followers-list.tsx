"use client"

import { useState } from "react"
import Image from "next/image"
import { MoreHorizontal, UserPlus, UserMinus, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import type { Follower } from "@/types/audience"

interface FollowersListProps {
  followers: Follower[]
}

export function FollowersList({ followers }: FollowersListProps) {
  const { toast } = useToast()
  const [localFollowers, setLocalFollowers] = useState<Follower[]>(followers)

  const handleToggleFollow = (id: string) => {
    setLocalFollowers(
      localFollowers.map((follower) =>
        follower.id === id ? { ...follower, youFollow: !follower.youFollow } : follower,
      ),
    )

    const follower = localFollowers.find((f) => f.id === id)
    toast({
      title: follower?.youFollow ? "Unfollowed" : "Followed",
      description: follower?.youFollow ? `You unfollowed @${follower.username}` : `You followed @${follower.username}`,
    })
  }

  if (localFollowers.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <p className="text-lg font-medium">No followers found</p>
        <p className="text-sm text-muted-foreground">No followers match your search criteria.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {localFollowers.map((follower) => (
        <div key={follower.id} className="flex items-center gap-4 rounded-lg border p-4">
          <div className="relative h-12 w-12 flex-shrink-0 overflow-hidden rounded-full">
            <Image
              src={follower.avatar || "/placeholder.svg?height=48&width=48"}
              alt={follower.displayName}
              fill
              className="object-cover"
              unoptimized
            />
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2">
              <p className="font-medium">{follower.displayName}</p>
              <span className="text-sm text-muted-foreground">@{follower.username}</span>
              {follower.isInfluencer && (
                <Badge variant="secondary" className="text-xs">
                  Influencer
                </Badge>
              )}
            </div>

            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span>Followers: {follower.followerCount.toLocaleString()}</span>
              <span>Engagement: {follower.engagementRate}%</span>
              {follower.lastActive && <span>Last active: {follower.lastActive}</span>}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant={follower.youFollow ? "outline" : "default"}
              size="sm"
              onClick={() => handleToggleFollow(follower.id)}
            >
              {follower.youFollow ? (
                <>
                  <UserMinus className="mr-1 h-4 w-4" /> Unfollow
                </>
              ) : (
                <>
                  <UserPlus className="mr-1 h-4 w-4" /> Follow
                </>
              )}
            </Button>

            <Button variant="ghost" size="icon">
              <MessageSquare className="h-4 w-4" />
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>View Profile</DropdownMenuItem>
                <DropdownMenuItem>Add to Segment</DropdownMenuItem>
                <DropdownMenuItem>Send Message</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ))}
    </div>
  )
}
