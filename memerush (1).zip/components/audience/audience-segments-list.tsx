"use client"

import { useState } from "react"
import { MoreHorizontal, Users, Edit, Trash2, BarChart3 } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import type { AudienceSegment } from "@/types/audience"

interface AudienceSegmentsListProps {
  segments: AudienceSegment[]
}

export function AudienceSegmentsList({ segments }: AudienceSegmentsListProps) {
  const { toast } = useToast()
  const [localSegments, setLocalSegments] = useState<AudienceSegment[]>(segments)

  const handleDeleteSegment = (id: string) => {
    // In a real app, this would call an API
    setLocalSegments(localSegments.filter((segment) => segment.id !== id))
    toast({
      title: "Segment deleted",
      description: "The audience segment has been deleted.",
    })
  }

  if (localSegments.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <p className="text-lg font-medium">No segments</p>
        <p className="text-sm text-muted-foreground">You haven&apos;t created any audience segments yet.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {localSegments.map((segment) => (
        <div key={segment.id} className="rounded-lg border p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="rounded-full bg-primary/10 p-2">
                <Users className="h-4 w-4 text-primary" />
              </div>
              <h3 className="font-medium">{segment.name}</h3>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <BarChart3 className="mr-2 h-4 w-4" /> View Analytics
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Edit className="mr-2 h-4 w-4" /> Edit Segment
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive focus:text-destructive"
                  onClick={() => handleDeleteSegment(segment.id)}
                >
                  <Trash2 className="mr-2 h-4 w-4" /> Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="mt-2 grid gap-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Audience Size:</span>
              <span>{segment.audienceSize.toLocaleString()} followers</span>
            </div>

            <div className="flex justify-between">
              <span className="text-muted-foreground">Created:</span>
              <span>{segment.createdAt}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-muted-foreground">Last Updated:</span>
              <span>{segment.updatedAt}</span>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap gap-1">
            {segment.criteria.map((criterion, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {criterion}
              </Badge>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
