"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, PieChart } from "@/components/analytics/charts"
import type { AudienceData } from "@/types/audience"

interface AudienceInsightsProps {
  data: AudienceData
}

export function AudienceInsights({ data }: AudienceInsightsProps) {
  return (
    <Tabs defaultValue="demographics" className="w-full">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="demographics">Demographics</TabsTrigger>
        <TabsTrigger value="interests">Interests</TabsTrigger>
        <TabsTrigger value="activity">Activity</TabsTrigger>
        <TabsTrigger value="location">Location</TabsTrigger>
      </TabsList>

      <TabsContent value="demographics" className="mt-4">
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Age Distribution</CardTitle>
              <CardDescription>Age groups of your audience</CardDescription>
            </CardHeader>
            <CardContent>
              <BarChart data={data.demographics.ageData} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Gender Distribution</CardTitle>
              <CardDescription>Gender breakdown of your audience</CardDescription>
            </CardHeader>
            <CardContent>
              <PieChart data={data.demographics.genderData} />
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="interests" className="mt-4">
        <Card>
          <CardHeader>
            <CardTitle>Top Interests</CardTitle>
            <CardDescription>What your audience cares about</CardDescription>
          </CardHeader>
          <CardContent>
            <BarChart data={data.interests} />
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="activity" className="mt-4">
        <Card>
          <CardHeader>
            <CardTitle>Activity Patterns</CardTitle>
            <CardDescription>When your audience is most active</CardDescription>
          </CardHeader>
          <CardContent>
            <BarChart data={data.activityPatterns} />
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="location" className="mt-4">
        <Card>
          <CardHeader>
            <CardTitle>Geographic Distribution</CardTitle>
            <CardDescription>Where your audience is located</CardDescription>
          </CardHeader>
          <CardContent>
            <BarChart data={data.locations} />
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  )
}
