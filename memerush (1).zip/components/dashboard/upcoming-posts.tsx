import { format } from "date-fns"
import { Calendar, Clock } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import type { ScheduledPost } from "@/types/content"

interface UpcomingPostsProps {
  posts: ScheduledPost[]
}

export function UpcomingPosts({ posts }: UpcomingPostsProps) {
  if (posts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <p className="text-lg font-medium">No upcoming posts</p>
        <p className="text-sm text-muted-foreground">You don&apos;t have any posts scheduled.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {posts.map((post) => (
        <div key={post.id} className="flex items-start gap-3 rounded-lg border p-3">
          <div className="mt-0.5 rounded-full bg-muted p-1">
            <Calendar className="h-4 w-4 text-primary" />
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-medium">{format(new Date(post.scheduledFor), "MMM d, yyyy")}</span>
              <Badge variant="outline" className="text-xs">
                <Clock className="mr-1 h-3 w-3" />
                {format(new Date(post.scheduledFor), "h:mm a")}
              </Badge>
            </div>
            <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{post.description}</p>
            <div className="mt-1 flex flex-wrap gap-1">
              {post.platforms.map((platform) => (
                <Badge key={platform} variant="secondary" className="text-xs">
                  {platform}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
