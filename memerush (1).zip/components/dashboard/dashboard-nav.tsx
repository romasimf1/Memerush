"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { BarChart3, Calendar, Users, Target, Settings, Home } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

export function DashboardNav() {
  const pathname = usePathname()

  const navItems = [
    {
      title: "Feed",
      href: "/feed",
      icon: Home,
    },
    {
      title: "Analytics",
      href: "/dashboard",
      icon: BarChart3,
    },
    {
      title: "Content",
      href: "/content/schedule",
      icon: Calendar,
    },
    {
      title: "Campaigns",
      href: "/campaigns",
      icon: Target,
    },
    {
      title: "Audience",
      href: "/audience",
      icon: Users,
    },
    {
      title: "Settings",
      href: "/settings",
      icon: Settings,
    },
  ]

  return (
    <nav className="grid items-start gap-2 px-2 py-4">
      {navItems.map((item) => (
        <Link key={item.href} href={item.href}>
          <Button
            variant={pathname === item.href ? "default" : "ghost"}
            className={cn(
              "w-full justify-start",
              pathname === item.href ? "bg-primary text-primary-foreground" : "text-muted-foreground",
            )}
          >
            <item.icon className="mr-2 h-4 w-4" />
            {item.title}
          </Button>
        </Link>
      ))}
    </nav>
  )
}
