import { format } from "date-fns"
import { Heart, MessageCircle, UserPlus, Share2 } from "lucide-react"
import type { Activity } from "@/types/analytics"

interface RecentActivityProps {
  activities: Activity[]
}

export function RecentActivity({ activities }: RecentActivityProps) {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "like":
        return <Heart className="h-4 w-4 text-red-500" />
      case "comment":
        return <MessageCircle className="h-4 w-4 text-blue-500" />
      case "follow":
        return <UserPlus className="h-4 w-4 text-green-500" />
      case "share":
        return <Share2 className="h-4 w-4 text-purple-500" />
      default:
        return null
    }
  }

  const getActivityText = (activity: Activity) => {
    switch (activity.type) {
      case "like":
        return (
          <span>
            <strong>@{activity.username}</strong> liked your meme
          </span>
        )
      case "comment":
        return (
          <span>
            <strong>@{activity.username}</strong> commented: "{activity.content}"
          </span>
        )
      case "follow":
        return (
          <span>
            <strong>@{activity.username}</strong> followed you
          </span>
        )
      case "share":
        return (
          <span>
            <strong>@{activity.username}</strong> shared your meme
          </span>
        )
      default:
        return null
    }
  }

  if (activities.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <p className="text-lg font-medium">No recent activity</p>
        <p className="text-sm text-muted-foreground">There hasn&apos;t been any activity on your content recently.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start gap-3">
          <div className="mt-0.5 rounded-full bg-muted p-1">{getActivityIcon(activity.type)}</div>

          <div className="flex-1">
            <div className="text-sm">{getActivityText(activity)}</div>
            <div className="text-xs text-muted-foreground">
              {format(new Date(activity.timestamp), "MMM d, yyyy 'at' h:mm a")}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
