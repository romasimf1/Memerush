import { BarChart } from "@/components/analytics/charts"
import type { AudienceData } from "@/types/analytics"

interface AudienceOverviewProps {
  data: AudienceData
}

export function AudienceOverview({ data }: AudienceOverviewProps) {
  return (
    <div>
      <BarChart data={data} />
    </div>
  )
}
