import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import { BarChart3, Heart, MessageCircle, Share2 } from "lucide-react"
import type { TopContent } from "@/types/analytics"

interface TopPerformingContentProps {
  data: TopContent[]
}

export function TopPerformingContent({ data }: TopPerformingContentProps) {
  if (data.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <p className="text-lg font-medium">No content data</p>
        <p className="text-sm text-muted-foreground">
          We don&apos;t have enough data to show top performing content yet.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {data.map((content) => (
        <div key={content.id} className="flex items-start gap-3">
          <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-md">
            <Image src={content.thumbnail || "/placeholder.svg"} alt="" fill className="object-cover" unoptimized />
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-medium line-clamp-1">{content.title}</span>
              <Badge variant="outline" className="text-xs">
                <BarChart3 className="mr-1 h-3 w-3" />
                {content.performance}
              </Badge>
            </div>

            <div className="mt-2 flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <Heart className="h-3 w-3" />
                <span>{content.likes.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-1">
                <MessageCircle className="h-3 w-3" />
                <span>{content.comments.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-1">
                <Share2 className="h-3 w-3" />
                <span>{content.shares.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
